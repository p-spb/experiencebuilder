System.register(["jimu-core","jimu-core/emotion","jimu-theme","jimu-ui","jimu-ui/advanced/data-source-selector","jimu-ui/basic/list-tree","jimu-ui/basic/sql-expression-runtime"],function(e,s){var t={},i={},a={},l={},o={},r={},n={};return{setters:[function(e){t.CONSTANTS=e.CONSTANTS,t.ClauseCascade=e.ClauseCascade,t.ClauseDisplayType=e.ClauseDisplayType,t.ClauseLabelDisplay=e.ClauseLabelDisplay,t.ClauseLogic=e.ClauseLogic,t.ClauseSourceType=e.ClauseSourceType,t.ClauseType=e.ClauseType,t.DataSourceComponent=e.DataSourceComponent,t.DataSourceTypes=e.DataSourceTypes,t.Immutable=e.Immutable,t.JimuFieldType=e.JimuFieldType,t.OrderRule=e.OrderRule,t.QueryScope=e.QueryScope,t.React=e.React,t.ReactResizeDetector=e.ReactResizeDetector,t.SqlExpressionMode=e.SqlExpressionMode,t.SqlQuerySortOrder=e.SqlQuerySortOrder,t.classNames=e.classNames,t.css=e.css,t.dataSourceUtils=e.dataSourceUtils,t.defaultMessages=e.defaultMessages,t.focusElementInKeyboardMode=e.focusElementInKeyboardMode,t.getAppStore=e.getAppStore,t.injectIntl=e.injectIntl,t.lodash=e.lodash,t.polished=e.polished,t.uuidv1=e.uuidv1},function(e){i.jsx=e.jsx,i.jsxs=e.jsxs},function(e){a.registerStyles=e.registerStyles,a.withStyles=e.withStyles,a.withTheme=e.withTheme},function(e){l.AdvancedButtonGroup=e.AdvancedButtonGroup,l.Badge=e.Badge,l.Button=e.Button,l.Checkbox=e.Checkbox,l.Dropdown=e.Dropdown,l.DropdownButton=e.DropdownButton,l.DropdownItem=e.DropdownItem,l.DropdownMenu=e.DropdownMenu,l.Icon=e.Icon,l.Label=e.Label,l.Modal=e.Modal,l.ModalBody=e.ModalBody,l.ModalFooter=e.ModalFooter,l.ModalHeader=e.ModalHeader,l.Option=e.Option,l.Popper=e.Popper,l.QueryScopeContext=e.QueryScopeContext,l.Radio=e.Radio,l.Select=e.Select,l.TextInput=e.TextInput,l.Tooltip=e.Tooltip,l.defaultMessages=e.defaultMessages},function(e){o.FieldSelector=e.FieldSelector},function(e){r.List=e.List,r.TreeItemActionType=e.TreeItemActionType},function(e){n.ClauseInputEditor=e.ClauseInputEditor,n.InputEditorRender=e.InputEditorRender,n.SqlExpressionSizeMode=e.SqlExpressionSizeMode,n.getCamelCase=e.getCamelCase,n.getClauseArrayByChange=e.getClauseArrayByChange,n.getClauseDefaultLabel=e.getClauseDefaultLabel,n.getClauseLabel=e.getClauseLabel,n.getDefaultClauseSet=e.getDefaultClauseSet,n.getDefaultClauseValObj=e.getDefaultClauseValObj,n.getDefaultGroupExpression=e.getDefaultGroupExpression,n.getDefaultSingleClause=e.getDefaultSingleClause,n.getDisplayTypes=e.getDisplayTypes,n.getInputEditorListByOperatorAndSourceType=e.getInputEditorListByOperatorAndSourceType,n.getOperatorsByShortType=e.getOperatorsByShortType,n.isAskForValueSupportedByOperatorAndSourceType=e.isAskForValueSupportedByOperatorAndSourceType,n.isCaseSensitiveSupportedByOperatorAndSourceType=e.isCaseSensitiveSupportedByOperatorAndSourceType,n.isSqlExpressionValid=e.isSqlExpressionValid}],execute:function(){e((()=>{var e={18180(e,s,t){var i={"./style_date_picker.svg":4392,"./style_date_picker_rtl.svg":38711,"./style_date_time_picker.svg":10898,"./style_date_time_picker_rtl.svg":30849,"./style_double_date_picker.svg":67448,"./style_double_date_picker_rtl.svg":47303,"./style_double_date_time_picker.svg":54306,"./style_double_date_time_picker_rtl.svg":91057,"./style_multiple_expanded_list.svg":2048,"./style_multiple_expanded_list_rtl.svg":58863,"./style_multiple_pill_wrap_selector.svg":97418,"./style_multiple_pill_wrap_selector_rtl.svg":56249,"./style_multiple_select.svg":13430,"./style_multiple_select_rtl.svg":22141,"./style_simple_expanded_list.svg":16962,"./style_simple_expanded_list_rtl.svg":79153,"./style_simple_select.svg":17488,"./style_simple_select_rtl.svg":72255,"./style_unique_pill_wrap_selector.svg":97353,"./style_unique_pill_wrap_selector_rtl.svg":79230};function a(e){var s=l(e);return t(s)}function l(e){if(!t.o(i,e)){var s=new Error("Cannot find module '"+e+"'");throw s.code="MODULE_NOT_FOUND",s}return i[e]}a.keys=function(){return Object.keys(i)},a.resolve=l,e.exports=a,a.id=18180},83710(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 16"><path fill="#000" fill-rule="evenodd" d="M8 1C4.15 1 1 4.15 1 8s3.15 7 7 7 7-3.15 7-7-3.15-7-7-7m1.167 11.667H6.834v-2.334h2.333zm-2.333-4.5V3.333h2.333v4.834z" clip-rule="evenodd"></path></svg>'},60158(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 16"><path fill="#000" fill-rule="evenodd" d="M9.839 2.748c-.807-1.294-2.871-1.294-3.678 0L.274 13.163C-.517 14.432.499 16 2.113 16h11.774c1.614 0 2.63-1.568 1.839-2.837zM7 6a1 1 0 0 1 2 0v4a1 1 0 1 1-2 0zm0 7a1 1 0 1 1 2 0 1 1 0 0 1-2 0" clip-rule="evenodd"></path></svg>'},8491(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" data-auto-flip="true" viewBox="0 0 16 16"><path fill="#000" fill-rule="evenodd" d="M2.5 3a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1zm0 3a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1zM2 9.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 0 1h-2a.5.5 0 0 1-.5-.5m.5 2.5a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1zM7 3.5a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5M7.5 6a.5.5 0 0 0 0 1h6a.5.5 0 0 0 0-1zM7 9.5a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5m.5 2.5a.5.5 0 0 0 0 1h6a.5.5 0 0 0 0-1z" clip-rule="evenodd"></path></svg>'},90131(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" data-auto-flip="true" viewBox="0 0 16 16"><path fill="#000" fill-rule="evenodd" d="M2.5 3a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1zm0 3a.5.5 0 0 0 0 1h11a.5.5 0 0 0 0-1zM2 12.5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5M2.5 9a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1z" clip-rule="evenodd"></path></svg>'},54112(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 16"><path fill="#000" fill-rule="evenodd" d="M9.438.994c.213 0 .397.146.44.35q.227 1.084.316 1.852.562.242 1.048.599l1.728-.676a.455.455 0 0 1 .556.188l1.42 2.394a.43.43 0 0 1-.091.547 22 22 0 0 1-1.49 1.194q.03.27.03.552 0 .32-.038.63l1.465 1.12a.43.43 0 0 1 .111.563l-1.42 2.394a.454.454 0 0 1-.53.197 23 23 0 0 1-1.807-.66q-.49.35-1.055.586l-.263 1.794a.446.446 0 0 1-.445.376H6.574a.446.446 0 0 1-.44-.35 21 21 0 0 1-.317-1.853 5.3 5.3 0 0 1-1.047-.598l-1.728.675a.455.455 0 0 1-.556-.187l-1.42-2.395a.43.43 0 0 1 .091-.546q.85-.735 1.49-1.194a5.167 5.167 0 0 1 .008-1.183L1.19 6.243a.43.43 0 0 1-.112-.562l1.42-2.395a.455.455 0 0 1 .531-.196q1.078.35 1.807.66c.324-.233.679-.43 1.056-.587l.262-1.794A.446.446 0 0 1 6.6.994zm-.365 1H6.985l-.28 1.866-.467.19q-.353.144-.672.34l-.207.136-.42.293-.476-.197q-.492-.205-1.169-.433l-.221-.074-1.045 1.719L3.59 6.999l-.06.479a4 4 0 0 0-.021.816l.014.144.058.492-.419.294q-.433.304-.979.746l-.177.145 1.043 1.72 1.845-.703.406.29q.307.219.645.384l.228.103.474.199.059.49q.06.507.19 1.177l.043.219h2.088l.282-1.867.466-.19q.354-.144.672-.34l.207-.136.419-.293.476.198q.495.204 1.17.433l.22.072 1.044-1.718-1.56-1.165.06-.479a4 4 0 0 0 .02-.815l-.013-.144-.06-.492.42-.295a18 18 0 0 0 .98-.746l.176-.146-1.043-1.72-1.844.705-.406-.29a4.5 4.5 0 0 0-.646-.385l-.228-.103-.474-.199-.058-.49q-.049-.405-.14-.916zm-1.067 3a3 3 0 1 1 0 6 3 3 0 0 1 0-6m0 1a2 2 0 1 0 0 4 2 2 0 0 0 0-4" clip-rule="evenodd"></path></svg>'},58593(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 16"><path fill="#000" fill-rule="evenodd" d="M15 2H1v5h14zm-1 1v3H2V3zM5 4H3v1h2zM1 9h14v5H1zm13 4v-3H2v3zm-9-2H3v1h2z" clip-rule="evenodd"></path></svg>'},80075(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" data-auto-flip="true" viewBox="0 0 16 16"><path fill="#000" d="M1.5 3a.5.5 0 0 0 0 1h4a.5.5 0 0 0 0-1zM1 6.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5M1.5 9a.5.5 0 0 0 0 1h10a.5.5 0 0 0 0-1zM1.5 12a.5.5 0 0 0 0 1h13a.5.5 0 0 0 0-1z"></path></svg>'},14089(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" data-auto-flip="true" viewBox="0 0 16 16"><path fill="#000" d="M1.5 13a.5.5 0 0 1 0-1h4a.5.5 0 0 1 0 1zM1 9.5a.5.5 0 0 0 .5.5h7a.5.5 0 0 0 0-1h-7a.5.5 0 0 0-.5.5M1.5 7a.5.5 0 0 1 0-1h10a.5.5 0 0 1 0 1zM1.5 4a.5.5 0 0 1 0-1h13a.5.5 0 0 1 0 1z"></path></svg>'},11595(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 16"><path fill="#000" d="m8.745 8 6.1 6.1a.527.527 0 1 1-.745.746L8 8.746l-6.1 6.1a.527.527 0 1 1-.746-.746l6.1-6.1-6.1-6.1a.527.527 0 0 1 .746-.746l6.1 6.1 6.1-6.1a.527.527 0 0 1 .746.746z"></path></svg>'},23932(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 16"><path fill="#000" fill-rule="evenodd" d="M1.5 11a.5.5 0 0 0 .5-.5V2h8.5a.5.5 0 0 0 0-1H2a1 1 0 0 0-1 1v8.5a.5.5 0 0 0 .5.5M5 4h9a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1m0 1v9h9V5z" clip-rule="evenodd"></path></svg>'},5629(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 16"><path fill="#000" d="M7.5 0a.5.5 0 0 0-.5.5V7H.5a.5.5 0 0 0 0 1H7v6.5a.5.5 0 0 0 1 0V8h6.5a.5.5 0 0 0 0-1H8V.5a.5.5 0 0 0-.5-.5"></path></svg>'},85543(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 16"><path fill="#000" d="M1.102 12.833H0L4.268 3h.976l4.24 9.833H8.368L7.28 10.25H2.176zm1.45-3.5h4.352L4.728 4.111zM14.996 8.639q0-.847-.447-1.264-.446-.417-1.297-.417-.586 0-1.087.209a2.6 2.6 0 0 0-.851.555l-.53-.625q.405-.402 1.06-.666a4.1 4.1 0 0 1 1.506-.264q.53 0 .99.152.46.14.81.431.348.292.543.736t.195 1.042v2.847q0 .376.028.778.029.402.084.68h-.85a7 7 0 0 1-.07-.514 5 5 0 0 1-.028-.541h-.028q-.447.653-1.018.944-.558.278-1.353.278-.377 0-.781-.111a2.2 2.2 0 0 1-.726-.333 2.05 2.05 0 0 1-.544-.612q-.209-.375-.209-.916 0-.75.377-1.18.39-.446 1.032-.654.642-.222 1.464-.277.837-.07 1.73-.07zm-.28.944q-.585 0-1.185.056-.585.041-1.074.194a2 2 0 0 0-.78.417q-.307.277-.307.736 0 .348.125.583.14.236.363.39.223.138.488.208.279.055.558.055.502 0 .892-.166.391-.18.656-.473.265-.305.404-.694.14-.389.14-.82v-.486z"></path></svg>'},4392(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#363636" fill-rule="evenodd" d="M4 15.5A1.5 1.5 0 0 1 5.5 14h57a1.5 1.5 0 0 1 1.493 1.355L64 15.5v27a1.5 1.5 0 0 1-1.5 1.5h-57A1.5 1.5 0 0 1 4 42.5zm59 0a.5.5 0 0 0-.5-.5h-57a.5.5 0 0 0-.5.5v27a.5.5 0 0 0 .5.5h57a.5.5 0 0 0 .5-.5z" clip-rule="evenodd"></path><path fill="#363636" d="M8 18h4v4H8zM38 18h4v4h-4zM33 18h1v22h-1zM14 18h4v4h-4zM44 18h4v4h-4zM20 18h4v4h-4zM50 18h4v4h-4zM26 18h4v4h-4zM56 18h4v4h-4zM8 30h4v4H8zM38 30h4v4h-4zM14 30h4v4h-4zM44 30h4v4h-4zM50 30h4v4h-4zM20 30h4v4h-4zM26 30h4v4h-4zM56 30h4v4h-4zM8 36h4v4H8zM38 36h4v4h-4zM14 36h4v4h-4zM44 36h4v4h-4zM20 36h4v4h-4zM8 24h4v4H8zM38 24h4v4h-4z"></path><path fill="#6A6A6A" d="M14 24h4v4h-4z"></path><path fill="#363636" d="M44 24h4v4h-4zM20 24h4v4h-4zM50 24h4v4h-4zM26 24h4v4h-4zM56 24h4v4h-4z"></path><rect width="60" height="8" x="4" y="4" fill="#6A6A6A" rx="1"></rect><path fill="#181818" d="M7 7h54v2H7z"></path></svg>'},38711(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#363636" fill-rule="evenodd" d="M64 15.5a1.5 1.5 0 0 0-1.5-1.5h-57a1.5 1.5 0 0 0-1.493 1.355L4 15.5v27A1.5 1.5 0 0 0 5.5 44h57a1.5 1.5 0 0 0 1.5-1.5zm-59 0a.5.5 0 0 1 .5-.5h57a.5.5 0 0 1 .5.5v27a.5.5 0 0 1-.5.5h-57a.5.5 0 0 1-.5-.5z" clip-rule="evenodd"></path><path fill="#363636" d="M60 18h-4v4h4zM30 18h-4v4h4zM35 18h-1v22h1zM54 18h-4v4h4zM24 18h-4v4h4zM48 18h-4v4h4zM18 18h-4v4h4zM42 18h-4v4h4zM12 18H8v4h4zM60 30h-4v4h4zM30 30h-4v4h4zM54 30h-4v4h4zM24 30h-4v4h4zM18 30h-4v4h4zM48 30h-4v4h4zM42 30h-4v4h4zM12 30H8v4h4zM60 36h-4v4h4zM30 36h-4v4h4zM54 36h-4v4h4zM24 36h-4v4h4zM48 36h-4v4h4zM60 24h-4v4h4zM30 24h-4v4h4z"></path><path fill="#6A6A6A" d="M54 24h-4v4h4z"></path><path fill="#363636" d="M24 24h-4v4h4zM48 24h-4v4h4zM18 24h-4v4h4zM42 24h-4v4h4zM12 24H8v4h4z"></path><rect width="60" height="8" fill="#6A6A6A" rx="1" transform="matrix(-1 0 0 1 64 4)"></rect><path fill="#181818" d="M61 7H7v2h54z"></path></svg>'},10898(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#363636" fill-rule="evenodd" d="M4 15.5A1.5 1.5 0 0 1 5.5 14h57a1.5 1.5 0 0 1 1.493 1.355L64 15.5v27a1.5 1.5 0 0 1-1.5 1.5h-57A1.5 1.5 0 0 1 4 42.5zm59 0a.5.5 0 0 0-.5-.5h-57a.5.5 0 0 0-.5.5v27a.5.5 0 0 0 .5.5h57a.5.5 0 0 0 .5-.5z" clip-rule="evenodd"></path><path fill="#363636" d="M8 18h4v4H8zM38 18h4v4h-4zM33 18h1v22h-1zM14 18h4v4h-4zM44 18h4v4h-4zM20 18h4v4h-4zM50 18h4v4h-4zM26 18h4v4h-4zM56 18h4v4h-4zM8 30h4v4H8zM38 30h4v4h-4zM14 30h4v4h-4zM20 30h4v4h-4zM26 30h4v4h-4zM8 36h4v4H8zM38 36h4v4h-4zM14 36h4v4h-4zM20 36h4v4h-4zM8 24h4v4H8zM38 24h4v4h-4z"></path><path fill="#6A6A6A" d="M14 24h4v4h-4z"></path><path fill="#363636" d="M44 24h4v4h-4z"></path><path fill="#6A6A6A" fill-rule="evenodd" d="M54.5 41a6.5 6.5 0 1 1 0-13 6.5 6.5 0 1 1 0 13m0-11.782a5.281 5.281 0 1 0 0 10.562 5.281 5.281 0 0 0 0-10.562m0 5.891h2.64a.605.605 0 0 0 .61-.609.61.61 0 0 0-.61-.609H55.11v-3.048a.608.608 0 1 0-1.218 0V34.5c0 .338.273.61.609.61" clip-rule="evenodd"></path><path fill="#363636" d="M20 24h4v4h-4zM26 24h4v4h-4z"></path><rect width="60" height="8" x="4" y="4" fill="#6A6A6A" rx="1"></rect><path fill="#181818" d="M7 7h34v2H7zM44 7h17v2H44z"></path></svg>'},30849(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#363636" fill-rule="evenodd" d="M64 15.5a1.5 1.5 0 0 0-1.5-1.5h-57a1.5 1.5 0 0 0-1.493 1.355L4 15.5v27A1.5 1.5 0 0 0 5.5 44h57a1.5 1.5 0 0 0 1.5-1.5zm-59 0a.5.5 0 0 1 .5-.5h57a.5.5 0 0 1 .5.5v27a.5.5 0 0 1-.5.5h-57a.5.5 0 0 1-.5-.5z" clip-rule="evenodd"></path><path fill="#363636" d="M60 18h-4v4h4zM30 18h-4v4h4zM35 18h-1v22h1zM54 18h-4v4h4zM24 18h-4v4h4zM48 18h-4v4h4zM18 18h-4v4h4zM42 18h-4v4h4zM12 18H8v4h4zM60 30h-4v4h4zM30 30h-4v4h4zM54 30h-4v4h4zM48 30h-4v4h4zM42 30h-4v4h4zM60 36h-4v4h4zM30 36h-4v4h4zM54 36h-4v4h4zM48 36h-4v4h4zM60 24h-4v4h4zM30 24h-4v4h4z"></path><path fill="#6A6A6A" d="M54 24h-4v4h4z"></path><path fill="#363636" d="M24 24h-4v4h4z"></path><path fill="#6A6A6A" fill-rule="evenodd" d="M13.5 41a6.5 6.5 0 1 0 0-13 6.5 6.5 0 1 0 0 13m0-11.782a5.281 5.281 0 1 1 0 10.562 5.281 5.281 0 0 1 0-10.562m.11 5.891h2.639a.605.605 0 0 0 .61-.609.61.61 0 0 0-.61-.609h-2.03v-3.048a.608.608 0 1 0-1.219 0V34.5c0 .338.273.61.61.61" clip-rule="evenodd"></path><path fill="#363636" d="M48 24h-4v4h4zM42 24h-4v4h4z"></path><rect width="60" height="8" fill="#6A6A6A" rx="1" transform="matrix(-1 0 0 1 64 4)"></rect><path fill="#181818" d="M61 7H27v2h34zM24 7H7v2h17z"></path></svg>'},67448(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#363636" fill-rule="evenodd" d="M4 15.5A1.5 1.5 0 0 1 5.5 14h57a1.5 1.5 0 0 1 1.493 1.355L64 15.5v27a1.5 1.5 0 0 1-1.5 1.5h-57A1.5 1.5 0 0 1 4 42.5zm59 0a.5.5 0 0 0-.5-.5h-57a.5.5 0 0 0-.5.5v27a.5.5 0 0 0 .5.5h57a.5.5 0 0 0 .5-.5z" clip-rule="evenodd"></path><path fill="#363636" d="M8 18h4v4H8z"></path><path fill="#6A6A6A" d="M38 18h4v4h-4z"></path><path fill="#363636" d="M33 18h1v22h-1zM14 18h4v4h-4z"></path><path fill="#6A6A6A" d="M44 18h4v4h-4z"></path><path fill="#363636" d="M20 18h4v4h-4z"></path><path fill="#6A6A6A" d="M50 18h4v4h-4z"></path><path fill="#363636" d="M26 18h4v4h-4z"></path><path fill="#6A6A6A" d="M56 18h4v4h-4z"></path><path fill="#363636" d="M8 30h4v4H8zM38 30h4v4h-4zM14 30h4v4h-4zM44 30h4v4h-4zM20 30h4v4h-4zM50 30h4v4h-4zM26 30h4v4h-4zM56 30h4v4h-4zM8 36h4v4H8zM38 36h4v4h-4z"></path><path fill="#6A6A6A" d="M14 36h4v4h-4z"></path><path fill="#363636" d="M44 36h4v4h-4z"></path><path fill="#6A6A6A" d="M20 36h4v4h-4z"></path><path fill="#363636" d="M8 24h4v4H8z"></path><path fill="#6A6A6A" d="M38 24h4v4h-4z"></path><path fill="#363636" d="M14 24h4v4h-4z"></path><path fill="#6A6A6A" d="M44 24h4v4h-4z"></path><path fill="#363636" d="M20 24h4v4h-4zM50 24h4v4h-4zM26 24h4v4h-4zM56 24h4v4h-4z"></path><rect width="28" height="8" x="4" y="4" fill="#6A6A6A" rx="1"></rect><rect width="28" height="8" x="36" y="4" fill="#6A6A6A" rx="1"></rect><path fill="#181818" d="M7 7h22v2H7zM39 7h22v2H39z"></path></svg>'},47303(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#363636" fill-rule="evenodd" d="M64 15.5a1.5 1.5 0 0 0-1.5-1.5h-57a1.5 1.5 0 0 0-1.493 1.355L4 15.5v27A1.5 1.5 0 0 0 5.5 44h57a1.5 1.5 0 0 0 1.5-1.5zm-59 0a.5.5 0 0 1 .5-.5h57a.5.5 0 0 1 .5.5v27a.5.5 0 0 1-.5.5h-57a.5.5 0 0 1-.5-.5z" clip-rule="evenodd"></path><path fill="#363636" d="M60 18h-4v4h4z"></path><path fill="#6A6A6A" d="M30 18h-4v4h4z"></path><path fill="#363636" d="M35 18h-1v22h1zM54 18h-4v4h4z"></path><path fill="#6A6A6A" d="M24 18h-4v4h4z"></path><path fill="#363636" d="M48 18h-4v4h4z"></path><path fill="#6A6A6A" d="M18 18h-4v4h4z"></path><path fill="#363636" d="M42 18h-4v4h4z"></path><path fill="#6A6A6A" d="M12 18H8v4h4z"></path><path fill="#363636" d="M60 30h-4v4h4zM30 30h-4v4h4zM54 30h-4v4h4zM24 30h-4v4h4zM48 30h-4v4h4zM18 30h-4v4h4zM42 30h-4v4h4zM12 30H8v4h4zM60 36h-4v4h4zM30 36h-4v4h4z"></path><path fill="#6A6A6A" d="M54 36h-4v4h4z"></path><path fill="#363636" d="M24 36h-4v4h4z"></path><path fill="#6A6A6A" d="M48 36h-4v4h4z"></path><path fill="#363636" d="M60 24h-4v4h4z"></path><path fill="#6A6A6A" d="M30 24h-4v4h4z"></path><path fill="#363636" d="M54 24h-4v4h4z"></path><path fill="#6A6A6A" d="M24 24h-4v4h4z"></path><path fill="#363636" d="M48 24h-4v4h4zM18 24h-4v4h4zM42 24h-4v4h4zM12 24H8v4h4z"></path><rect width="28" height="8" fill="#6A6A6A" rx="1" transform="matrix(-1 0 0 1 64 4)"></rect><rect width="28" height="8" fill="#6A6A6A" rx="1" transform="matrix(-1 0 0 1 32 4)"></rect><path fill="#181818" d="M61 7H39v2h22zM29 7H7v2h22z"></path></svg>'},54306(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#363636" fill-rule="evenodd" d="M4 15.5A1.5 1.5 0 0 1 5.5 14h57a1.5 1.5 0 0 1 1.493 1.355L64 15.5v27a1.5 1.5 0 0 1-1.5 1.5h-57A1.5 1.5 0 0 1 4 42.5zm59 0a.5.5 0 0 0-.5-.5h-57a.5.5 0 0 0-.5.5v27a.5.5 0 0 0 .5.5h57a.5.5 0 0 0 .5-.5z" clip-rule="evenodd"></path><path fill="#363636" d="M8 18h4v4H8z"></path><path fill="#6A6A6A" d="M38 18h4v4h-4z"></path><path fill="#363636" d="M33 18h1v22h-1zM14 18h4v4h-4z"></path><path fill="#6A6A6A" d="M44 18h4v4h-4z"></path><path fill="#363636" d="M20 18h4v4h-4z"></path><path fill="#6A6A6A" d="M50 18h4v4h-4z"></path><path fill="#363636" d="M26 18h4v4h-4z"></path><path fill="#6A6A6A" d="M56 18h4v4h-4z"></path><path fill="#363636" d="M8 30h4v4H8zM38 30h4v4h-4zM14 30h4v4h-4zM20 30h4v4h-4zM26 30h4v4h-4zM8 36h4v4H8zM38 36h4v4h-4z"></path><path fill="#6A6A6A" d="M14 36h4v4h-4zM20 36h4v4h-4z"></path><path fill="#363636" d="M8 24h4v4H8z"></path><path fill="#6A6A6A" d="M38 24h4v4h-4z"></path><path fill="#363636" d="M14 24h4v4h-4z"></path><path fill="#6A6A6A" d="M44 24h4v4h-4z"></path><path fill="#6A6A6A" fill-rule="evenodd" d="M54.5 41a6.5 6.5 0 1 1 0-13 6.5 6.5 0 1 1 0 13m0-11.782a5.281 5.281 0 1 0 0 10.562 5.281 5.281 0 0 0 0-10.562m0 5.891h2.64a.605.605 0 0 0 .61-.609.61.61 0 0 0-.61-.609H55.11v-3.048a.608.608 0 1 0-1.218 0V34.5c0 .338.273.61.609.61" clip-rule="evenodd"></path><path fill="#363636" d="M20 24h4v4h-4zM26 24h4v4h-4z"></path><rect width="28" height="8" x="4" y="4" fill="#6A6A6A" rx="1"></rect><rect width="28" height="8" x="36" y="4" fill="#6A6A6A" rx="1"></rect><path fill="#181818" d="M7 7h13v2H7zM39 7h13v2H39zM22 7h7v2h-7zM54 7h7v2h-7z"></path></svg>'},91057(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#363636" fill-rule="evenodd" d="M64 15.5a1.5 1.5 0 0 0-1.5-1.5h-57a1.5 1.5 0 0 0-1.493 1.355L4 15.5v27A1.5 1.5 0 0 0 5.5 44h57a1.5 1.5 0 0 0 1.5-1.5zm-59 0a.5.5 0 0 1 .5-.5h57a.5.5 0 0 1 .5.5v27a.5.5 0 0 1-.5.5h-57a.5.5 0 0 1-.5-.5z" clip-rule="evenodd"></path><path fill="#363636" d="M60 18h-4v4h4z"></path><path fill="#6A6A6A" d="M30 18h-4v4h4z"></path><path fill="#363636" d="M35 18h-1v22h1zM54 18h-4v4h4z"></path><path fill="#6A6A6A" d="M24 18h-4v4h4z"></path><path fill="#363636" d="M48 18h-4v4h4z"></path><path fill="#6A6A6A" d="M18 18h-4v4h4z"></path><path fill="#363636" d="M42 18h-4v4h4z"></path><path fill="#6A6A6A" d="M12 18H8v4h4z"></path><path fill="#363636" d="M60 30h-4v4h4zM30 30h-4v4h4zM54 30h-4v4h4zM48 30h-4v4h4zM42 30h-4v4h4zM60 36h-4v4h4zM30 36h-4v4h4z"></path><path fill="#6A6A6A" d="M54 36h-4v4h4zM48 36h-4v4h4z"></path><path fill="#363636" d="M60 24h-4v4h4z"></path><path fill="#6A6A6A" d="M30 24h-4v4h4z"></path><path fill="#363636" d="M54 24h-4v4h4z"></path><path fill="#6A6A6A" d="M24 24h-4v4h4z"></path><path fill="#6A6A6A" fill-rule="evenodd" d="M13.5 41a6.5 6.5 0 1 0 0-13 6.5 6.5 0 1 0 0 13m0-11.782a5.281 5.281 0 1 1 0 10.562 5.281 5.281 0 0 1 0-10.562m.11 5.891h2.639a.605.605 0 0 0 .61-.609.61.61 0 0 0-.61-.609h-2.03v-3.048a.608.608 0 1 0-1.219 0V34.5c0 .338.273.61.61.61" clip-rule="evenodd"></path><path fill="#363636" d="M48 24h-4v4h4zM42 24h-4v4h4z"></path><rect width="28" height="8" fill="#6A6A6A" rx="1" transform="matrix(-1 0 0 1 64 4)"></rect><rect width="28" height="8" fill="#6A6A6A" rx="1" transform="matrix(-1 0 0 1 32 4)"></rect><path fill="#181818" d="M61 7H48v2h13zM29 7H16v2h13zM46 7h-7v2h7zM14 7H7v2h7z"></path></svg>'},2048(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#181818" d="M0 0h68v48H0z"></path><path fill="#363636" d="M63 10c.552 0 1 .508 1 1.134v31.732c0 .626-.448 1.134-1 1.134H5c-.552 0-1-.508-1-1.134V11.134C4 10.508 4.448 10 5 10zM5 42.866h58V11.134H5z"></path><path fill="#6A6A6A" d="M16 28h44v2H16zM16 36h44v2H16zM4 4h28v3H4z"></path><path fill="#999" d="m13.055 27.16-2.662 2.623-1.448-1.433a.56.56 0 0 0-.783 0 .546.546 0 0 0 0 .776l1.733 1.715c.117.116.325.168.498.158.173.007.381-.046.494-.157l2.951-2.906a.547.547 0 0 0 0-.776.56.56 0 0 0-.783 0M13.055 35.16l-2.662 2.623-1.448-1.433a.56.56 0 0 0-.783 0 .546.546 0 0 0 0 .776l1.733 1.716c.117.115.325.167.498.157.173.007.381-.046.494-.157l2.951-2.907a.547.547 0 0 0 0-.775.56.56 0 0 0-.783 0"></path><path fill="#6A6A6A" d="M58.204 14.01A2 2 0 0 1 60 16v4l-.01.204a2 2 0 0 1-1.786 1.785L58 22H10a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h48zM10 15a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h48a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1zm.414 1.414a1.998 1.998 0 0 1 3.135 2.428l1.108 1.108-.707.707-1.108-1.108a1.998 1.998 0 0 1-2.428-3.135M32 19H16v-2h16zm-19.465-1.879a1 1 0 1 0-1.414 1.415 1 1 0 0 0 1.414-1.415"></path></svg>'},58863(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#181818" d="M0 0h68v48H0z"></path><path fill="#363636" d="M63 10c.552 0 1 .508 1 1.134v31.732c0 .626-.448 1.134-1 1.134H5c-.552 0-1-.508-1-1.134V11.134C4 10.508 4.448 10 5 10zM5 42.866h58V11.134H5z"></path><path fill="#6A6A6A" d="M8 28h44v2H8zM8 36h44v2H8zM36 4h28v3H36z"></path><path fill="#999" d="m59.055 27.16-2.662 2.623-1.448-1.433a.56.56 0 0 0-.784 0 .546.546 0 0 0 0 .776l1.734 1.715c.117.116.325.168.498.158.173.007.381-.046.494-.157l2.952-2.906a.547.547 0 0 0 0-.776.56.56 0 0 0-.784 0M59.055 35.16l-2.662 2.623-1.448-1.433a.56.56 0 0 0-.784 0 .546.546 0 0 0 0 .776l1.734 1.716c.117.115.325.167.498.157.173.007.381-.046.494-.157l2.952-2.907a.547.547 0 0 0 0-.775.56.56 0 0 0-.784 0"></path><path fill="#6A6A6A" d="M58.204 14.01A2 2 0 0 1 60 16v4l-.01.204a2 2 0 0 1-1.786 1.785L58 22H10a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h48zM10 15a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h48a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1zm43.586 1.414a1.998 1.998 0 0 1 3.135 2.428l1.107 1.108-.707.707-1.107-1.108a1.998 1.998 0 0 1-2.428-3.135M51 19H35v-2h16zm4.707-1.879a1 1 0 1 0-1.414 1.415 1 1 0 0 0 1.414-1.415"></path></svg>'},97418(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><rect width="15" height="8" x="32" y="24" fill="#363636" rx="1"></rect><rect width="15" height="8" x="49" y="24" fill="#363636" rx="1"></rect><rect width="26" height="8" x="4" y="24" fill="#363636" rx="1"></rect><rect width="19" height="8" x="4" y="4" fill="#6A6A6A" rx="1"></rect><rect width="34" height="8" x="4" y="14" fill="#6A6A6A" rx="1"></rect><rect width="15" height="8" x="45" y="4" fill="#363636" rx="1"></rect><rect width="18" height="8" x="25" y="4" fill="#6A6A6A" rx="1"></rect><rect width="24" height="8" x="40" y="14" fill="#363636" rx="1"></rect><rect width="24" height="8" x="4" y="34" fill="#363636" rx="1"></rect></svg>'},56249(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><rect width="15" height="8" fill="#363636" rx="1" transform="matrix(-1 0 0 1 36 24)"></rect><rect width="15" height="8" fill="#363636" rx="1" transform="matrix(-1 0 0 1 19 24)"></rect><rect width="26" height="8" fill="#363636" rx="1" transform="matrix(-1 0 0 1 64 24)"></rect><rect width="19" height="8" fill="#6A6A6A" rx="1" transform="matrix(-1 0 0 1 64 4)"></rect><rect width="34" height="8" fill="#6A6A6A" rx="1" transform="matrix(-1 0 0 1 64 14)"></rect><rect width="15" height="8" fill="#363636" rx="1" transform="matrix(-1 0 0 1 23 4)"></rect><rect width="18" height="8" fill="#6A6A6A" rx="1" transform="matrix(-1 0 0 1 43 4)"></rect><rect width="24" height="8" fill="#363636" rx="1" transform="matrix(-1 0 0 1 28 14)"></rect><rect width="24" height="8" fill="#363636" rx="1" transform="matrix(-1 0 0 1 64 34)"></rect></svg>'},13430(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#363636" fill-rule="evenodd" d="M64 15a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v28a1 1 0 0 0 1 1h58a1 1 0 0 0 1-1zM5 15h58v28H5z" clip-rule="evenodd"></path><path fill="#6A6A6A" d="M16 20h44v2H16zM13.055 19.16l-2.662 2.623-1.448-1.433a.56.56 0 0 0-.783 0 .546.546 0 0 0 0 .776l1.733 1.715c.117.116.325.168.498.158.173.007.381-.046.494-.157l2.951-2.906a.547.547 0 0 0 0-.776.56.56 0 0 0-.783 0M13.055 27.16l-2.662 2.623-1.448-1.433a.56.56 0 0 0-.783 0 .546.546 0 0 0 0 .776l1.733 1.715c.117.116.325.168.498.158.173.007.381-.046.494-.157l2.951-2.906a.547.547 0 0 0 0-.776.56.56 0 0 0-.783 0M13.055 35.16l-2.662 2.623-1.448-1.433a.56.56 0 0 0-.783 0 .546.546 0 0 0 0 .776l1.733 1.716c.117.115.325.167.498.157.173.007.381-.046.494-.157l2.951-2.907a.547.547 0 0 0 0-.775.56.56 0 0 0-.783 0M16 28h44v2H16zM16 36h44v2H16z"></path><rect width="60" height="8" x="4" y="4" fill="#6A6A6A" rx="2"></rect><path fill="#181818" fill-rule="evenodd" d="M55 6h6l-3 4z" clip-rule="evenodd"></path><path fill="#181818" d="M7 7h46v2H7z"></path></svg>'},22141(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#363636" fill-rule="evenodd" d="M64 15a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v28a1 1 0 0 0 1 1h58a1 1 0 0 0 1-1zM5 15h58v28H5z" clip-rule="evenodd"></path><path fill="#6A6A6A" d="M52 20H8v2h44zM59.055 19.16l-2.662 2.623-1.448-1.433a.56.56 0 0 0-.784 0 .546.546 0 0 0 0 .776l1.734 1.715c.117.116.325.168.498.158.173.007.381-.046.494-.157l2.952-2.906a.547.547 0 0 0 0-.776.56.56 0 0 0-.784 0M59.055 27.16l-2.662 2.623-1.448-1.433a.56.56 0 0 0-.784 0 .546.546 0 0 0 0 .776l1.734 1.715c.117.116.325.168.498.158.173.007.381-.046.494-.157l2.952-2.906a.547.547 0 0 0 0-.776.56.56 0 0 0-.784 0M59.055 35.16l-2.662 2.623-1.448-1.433a.56.56 0 0 0-.784 0 .546.546 0 0 0 0 .776l1.734 1.716c.117.115.325.167.498.157.173.007.381-.046.494-.157l2.952-2.907a.547.547 0 0 0 0-.775.56.56 0 0 0-.784 0M52 28H8v2h44zM52 36H8v2h44z"></path><rect width="60" height="8" fill="#6A6A6A" rx="2" transform="matrix(-1 0 0 1 64 4)"></rect><path fill="#181818" fill-rule="evenodd" d="M13 6H7l3 4z" clip-rule="evenodd"></path><path fill="#181818" d="M61 7H15v2h46z"></path></svg>'},16962(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#181818" d="M0 0h68v48H0z"></path><path fill="#363636" d="M63 10c.552 0 1 .508 1 1.134v31.732c0 .626-.448 1.134-1 1.134H5c-.552 0-1-.508-1-1.134V11.134C4 10.508 4.448 10 5 10zM5 42.866h58V11.134H5z"></path><path fill="#6A6A6A" d="M16 28h44v2H16zM4 4h28v3H4z"></path><path fill="#999" d="m13.055 27.16-2.662 2.623-1.448-1.433a.56.56 0 0 0-.783 0 .546.546 0 0 0 0 .776l1.733 1.715c.117.116.325.168.498.158.173.007.381-.046.494-.157l2.951-2.906a.547.547 0 0 0 0-.776.56.56 0 0 0-.783 0"></path><path fill="#363636" d="M16 36h44v2H16z"></path><path fill="#6A6A6A" d="M58.204 14.01A2 2 0 0 1 60 16v4l-.01.204a2 2 0 0 1-1.786 1.785L58 22H10a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h48zM10 15a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h48a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1zm.414 1.414a1.998 1.998 0 0 1 3.135 2.428l1.108 1.108-.707.707-1.108-1.108a1.998 1.998 0 0 1-2.428-3.135M32 19H16v-2h16zm-19.465-1.879a1 1 0 1 0-1.414 1.415 1 1 0 0 0 1.414-1.415"></path></svg>'},79153(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#181818" d="M0 0h68v48H0z"></path><path fill="#363636" d="M63 10c.552 0 1 .508 1 1.134v31.732c0 .626-.448 1.134-1 1.134H5c-.552 0-1-.508-1-1.134V11.134C4 10.508 4.448 10 5 10zM5 42.866h58V11.134H5z"></path><path fill="#6A6A6A" d="M8 28h44v2H8z"></path><path fill="#363636" d="M8 36h44v2H8z"></path><path fill="#6A6A6A" d="M36 4h28v3H36z"></path><path fill="#999" d="m59.055 27.16-2.662 2.623-1.448-1.433a.56.56 0 0 0-.784 0 .546.546 0 0 0 0 .776l1.734 1.715c.117.116.325.168.498.158.173.007.381-.046.494-.157l2.952-2.906a.547.547 0 0 0 0-.776.56.56 0 0 0-.784 0"></path><path fill="#6A6A6A" d="M58.204 14.01A2 2 0 0 1 60 16v4l-.01.204a2 2 0 0 1-1.786 1.785L58 22H10a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h48zM10 15a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h48a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1zm43.586 1.414a1.998 1.998 0 0 1 3.135 2.428l1.107 1.108-.707.707-1.107-1.108a1.998 1.998 0 0 1-2.428-3.135M51 19H35v-2h16zm4.707-1.879a1 1 0 1 0-1.414 1.415 1 1 0 0 0 1.414-1.415"></path></svg>'},17488(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#363636" fill-rule="evenodd" d="M64 15a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v28a1 1 0 0 0 1 1h58a1 1 0 0 0 1-1zM5 15h58v28H5z" clip-rule="evenodd"></path><path fill="#6A6A6A" d="M16 20h44v2H16z"></path><path fill="#999" d="m13.055 19.16-2.662 2.623-1.448-1.433a.56.56 0 0 0-.783 0 .546.546 0 0 0 0 .776l1.733 1.715c.117.116.325.168.498.158.173.007.381-.046.494-.157l2.951-2.906a.547.547 0 0 0 0-.776.56.56 0 0 0-.783 0"></path><path fill="#363636" d="M16 28h44v2H16zM16 36h44v2H16z"></path><rect width="60" height="8" x="4" y="4" fill="#6A6A6A" rx="2"></rect><path fill="#181818" fill-rule="evenodd" d="M55 6h6l-3 4z" clip-rule="evenodd"></path><path fill="#181818" d="M7 7h46v2H7z"></path></svg>'},72255(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><path fill="#363636" fill-rule="evenodd" d="M4 15a1 1 0 0 1 1-1h58a1 1 0 0 1 1 1v28a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1zm59 0H5v28h58z" clip-rule="evenodd"></path><path fill="#6A6A6A" d="M52 20H8v2h44z"></path><path fill="#999" d="m59.055 19.16-2.662 2.623-1.448-1.433a.56.56 0 0 0-.784 0 .546.546 0 0 0 0 .776l1.734 1.715c.117.116.325.168.498.158.173.007.381-.046.494-.157l2.952-2.906a.547.547 0 0 0 0-.776.56.56 0 0 0-.784 0"></path><path fill="#363636" d="M52 28H8v2h44zM52 36H8v2h44z"></path><rect width="60" height="8" fill="#6A6A6A" rx="2" transform="matrix(-1 0 0 1 64 4)"></rect><path fill="#181818" fill-rule="evenodd" d="M13 6H7l3 4z" clip-rule="evenodd"></path><path fill="#181818" d="M61 7H15v2h46z"></path></svg>'},97353(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><rect width="15" height="8" x="32" y="24" fill="#363636" rx="1"></rect><rect width="15" height="8" x="49" y="24" fill="#363636" rx="1"></rect><rect width="26" height="8" x="4" y="24" fill="#363636" rx="1"></rect><rect width="19" height="8" x="4" y="4" fill="#6A6A6A" rx="1"></rect><rect width="34" height="8" x="4" y="14" fill="#363636" rx="1"></rect><rect width="15" height="8" x="45" y="4" fill="#363636" rx="1"></rect><rect width="18" height="8" x="25" y="4" fill="#363636" rx="1"></rect><rect width="24" height="8" x="40" y="14" fill="#363636" rx="1"></rect><rect width="24" height="8" x="4" y="34" fill="#363636" rx="1"></rect></svg>'},79230(e){e.exports='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 68 48"><rect width="15" height="8" fill="#363636" rx="1" transform="matrix(-1 0 0 1 36 24)"></rect><rect width="15" height="8" fill="#363636" rx="1" transform="matrix(-1 0 0 1 19 24)"></rect><rect width="26" height="8" fill="#363636" rx="1" transform="matrix(-1 0 0 1 64 24)"></rect><rect width="19" height="8" fill="#6A6A6A" rx="1" transform="matrix(-1 0 0 1 64 4)"></rect><rect width="34" height="8" fill="#363636" rx="1" transform="matrix(-1 0 0 1 64 14)"></rect><rect width="15" height="8" fill="#363636" rx="1" transform="matrix(-1 0 0 1 23 4)"></rect><rect width="18" height="8" fill="#363636" rx="1" transform="matrix(-1 0 0 1 43 4)"></rect><rect width="24" height="8" fill="#363636" rx="1" transform="matrix(-1 0 0 1 28 14)"></rect><rect width="24" height="8" fill="#363636" rx="1" transform="matrix(-1 0 0 1 64 34)"></rect></svg>'},79244(e){"use strict";e.exports=t},67386(e){"use strict";e.exports=i},1888(e){"use strict";e.exports=a},14321(e){"use strict";e.exports=l},13089(e){"use strict";e.exports=o},98640(e){"use strict";e.exports=r},76117(e){"use strict";e.exports=n}},s={};function p(t){var i=s[t];if(void 0!==i)return i.exports;var a=s[t]={exports:{}};return e[t](a,a.exports,p),a.exports}p.n=e=>{var s=e&&e.__esModule?()=>e.default:()=>e;return p.d(s,{a:s}),s},p.d=(e,s)=>{for(var t in s)p.o(s,t)&&!p.o(e,t)&&Object.defineProperty(e,t,{enumerable:!0,get:s[t]})},p.o=(e,s)=>Object.prototype.hasOwnProperty.call(e,s),p.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})};var h={};return(()=>{"use strict";p.r(h),p.d(h,{GroupSqlExpressionBuilderPopup:()=>Be,Sort:()=>De,SqlExpressionBuilder:()=>xe,SqlExpressionBuilderPopup:()=>be,_GroupSqlExpressionBuilderPopup:()=>ke,_SqlExpressionBuilder:()=>ve,_SqlExpressionBuilderPopup:()=>Me});var e={};p.r(e),p.d(e,{GroupSqlExpressionBuilder:()=>o,InputEditorTypeSelector:()=>l,Sort:()=>r,SqlExpressionBuilder:()=>t,SqlExpressionClause:()=>i,SqlExpressionClauseSet:()=>a});var s=p(79244);function t(e){return s.css`
    &.use-scroll{
      height: 100%;
      .sql-expression-builder{
          height: 100%;
          .sql-expression-container{
            height: 100%;
            .builder-btn-container{
              padding-right: 2px;
            }
            .sql-expression-list{
              padding-right: 2px;
              max-height: calc(100vh - 255px);
              height: calc(100% - 36px);
              overflow-y: auto;
              min-height: 55px; // ensure the no-data-tip can be displayed without scrollbar

              > div:first-child .sql-expression-set {
                margin-top: 6px;
              }
            }
          }
      }
    }

    .sql-expression-builder {
      padding: 14px 5px 5px 5px;
      .no-data-tip{
        text-align: center;
        margin: 2rem auto 0;
        opacity: 0.7;
      }

      .sql-expression-container {
        display: flex;
        flex-direction: column;
        gap: 20px;

        .sql-expression-list {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
      }

      .builder-btn-container{
        display: flex;
        .add-button-container{
          margin-left: auto;
        }
      }
      .add-button-container{
        display: flex;
      }
    }

    &.small-mode,
    &.medium-mode{
      .sql-expression-builder .sql-expression-clause{
        display: block;
        .clause-controllers-container{
          width: 100%;
          margin-left: 0;
        }
        .clause-style-container{
          .input-editor.is-sql-builder {
            width: ${`calc(100% - ${window.jimuConfig.isBuilder?32:40}px)!important`};
          }
        }
      }
    }

    &.small-mode{ /* 350px */
      .sql-expression-builder{
        padding: 0;
        .sql-expression-container{
          min-width: 300px;
          overflow-x: auto;
          overflow-y: hidden;
          gap: 15px;

          .sql-expression-list {
            gap: 16px;
            > div:first-child > .sql-expression-single,
            > div:first-child .sql-expression-set {
              margin-top: 12px;
            }
          }
          .sql-expression-single{
            padding: 0.25rem 1rem 0.5rem 1rem;
            .clause-main-container{
              display: block !important;

              .clause-field-and-operator{
                margin: 0.5rem 0 !important;
                justify-content: space-between;
                .clause-field-container {
                  margin: 0;
                  width: calc(60% - 0.25rem);
                }
                .clause-operator-container{
                  margin: 0;
                  width: calc(40% - 0.25rem);
                }
              }
              .clause-style-container{
                width: 100%;
                margin: 0.5rem 0 !important;
              }
              .source-type-selector {
                margin-left: 0 !important;
              }
            }
          }
          .sql-expression-set{
            .btn-container{
              padding: 0.75rem 1rem 0.5rem 1rem;
            }
            .sql-expression-single{
              margin-bottom: 0;
            }
          }
        }
      }
    }
    &.medium-mode{ /* 350px - 614px */
      .sql-expression-builder{
        .clause-field-container,
        .clause-operator-container{
          width: 123px;
        }
        .clause-style-container{
          width: calc(100% - 270px);
        }
      }
    }
    &.large-mode{ /* 915px */
      .sql-expression-builder{
        .clause-field-container,
        .clause-operator-container{
          width: 150px;
        }
        .clause-style-container{
          width: 380px;
        }
      }
    }

  `}function i(e){const t=e.theme;return s.css`
    .sql-expression-single {
      padding: 12px;
      margin-bottom: 0;
      border: ${window.jimuConfig.isBuilder?"0px":"1px"} solid ${t.sys.color.divider.secondary};
      border-top: 1px solid ${t.sys.color.divider.secondary};
      background-color: ${window.jimuConfig.isBuilder?t.sys.color.surface.paper:"transparent"};
      border-radius: ${window.jimuConfig.isBuilder?"0px":t.sys.shape.shape2};

      .sql-expression-clause{
        display: flex;
        align-items: center;
        .clause-main-container{
          display: flex;
          align-items: center;
          .clause-field-and-operator{
            display: flex;
            gap: 8px;
          }
          .clause-style-container{
            display: flex;
            flex-grow: 1;
            align-items: center;
            .source-type-selector{
              margin: 0 8px;
              .jimu-btn{
                &.jimu-dropdown-button-icon-dot .icon-btn-sizer:after {
                  border-top: 2px solid #fff;
                }
                .jimu-icon {
                  color: #fff !important;
                }
              }
            }
          }
        }

        .clause-controllers-container{
          width: 150px;
          margin-left: 16px;
          margin-right: 0;
          .case-sensitive-btn, .more-input-setting-btn, .duplicate-btn, .delete-btn{
            margin: 0 2px;
            .jimu-badge-badge {
              border-color: ${t.ref.palette.black};
            }
          }
          .case-sensitive-btn.disabled, .case-sensitive-btn.disabled:hover, .case-sensitive-btn:disabled:hover{
            border: none;
          }
          .case-sensitive-btn:disabled .jimu-icon, .more-input-setting-btn:disabled .jimu-icon{
            opacity: 0.5;
          }
          .more-input-setting-btn-active,
          .dropdown-active {
            background-color: ${t.sys.color.primary.main} !important;
            color: ${t.ref.palette.black} !important;
          }

          .case-sensitive-btn,
          .more-input-setting-btn,
          .duplicate-btn,
          .delete-btn{
            border-radius: 4px;
          }
        }
      }

      .ask-for-value-container{
        margin-top: 1.5rem;
        margin-left: 8px;
        .ask-for-value-radio{
          display: flex;
          margin: 10px 0;
        }
        .ask-for-value-options{
          display: flex;
          margin-left: 20px;
          margin-right: 20px;
          .ask-for-value-item{
            .ask-for-value-item-label{
              color: ${t.sys.color.surface.paperHint};
              margin-bottom: 3px;
            }
          }
          .ask-for-value-middle-item{
            margin: 0 0.1rem;
          }
          .use-label-input {
            margin-left: 0.5rem;
            width: 25%;
          }
        }
      }

      &.for-group-filter {
        border-top: none;
        .sql-expression-clause {
          .clause-main-container .clause-style-container .source-type-selector {
            margin-left: 0;
          }
          .clause-controllers-container {
            width: unset;
            margin: 0;
          }
        }
        .ask-for-value-container {
          .ask-for-value-radio-selector {
            display: block !important;
            .ask-for-value-middle-item {
              width: 100%;
              .style-type-selector {
                width: 100%;
                .style-button {
                  width: 100%;
                  button {
                    width: 100%;
                  }
                }
              }
            }
          }
          .ask-for-value-options {
            display: block;
            flex-direction: column;
            margin-right: 0;
            .ask-for-value-item {
              display: block;
            }
            .use-label-input {
              margin-left: 1.5rem;
              margin-top: 0.5rem;
              width: auto;
            }
          }
        }
      }
    }
  `}function a(e){const t=e.theme;return s.css`
    .sql-expression-set {
      border: ${window.jimuConfig.isBuilder?"0px":"1px"} solid ${t.sys.color.divider.secondary};
      border-top: 1px solid ${t.sys.color.divider.secondary};
      background-color: ${window.jimuConfig.isBuilder?t.sys.color.surface.paper:"transparent"};
      border-radius: ${window.jimuConfig.isBuilder?"0px":t.sys.shape.shape2};

      .btn-container{
        position: relative;
        display: flex;
        padding: 12px 12px 8px 12px;

        .jimu-btn{
          font-size: 12px;
        }

        .and-or-container{
          margin: 0;
        }

        .set-badge {
          position: absolute;
          top: -6px;
          left: 50%;
          transform: translateX(-50%);
          z-index: 0;
          padding: 0px 6px;
          font-size: 12px;
          font-weight: 400;
          color: ${window.jimuConfig.isBuilder?t.sys.color.surface.paperHint:"inherit"};
          background: linear-gradient(
            to bottom,
            var(--clause-set-badge-bg, ${t.sys.color.surface.paper}) 0%,
            var(--clause-set-badge-bg, ${t.sys.color.surface.paper}) 40%,
            transparent 40%,
            transparent 100%
          );
          border-radius: 6px 6px 0 0;
          user-select: none;

            &::before {
              content: "";
              position: absolute;
              inset: 0;
              border-radius: inherit;
              padding: 1px;
              background:linear-gradient(
                  180deg,
                  ${s.polished.rgba(t.sys.color.divider.secondary,1)} 0%,
                  ${s.polished.rgba(t.sys.color.divider.secondary,.5)} 40%,
                  ${s.polished.rgba(t.sys.color.divider.secondary,.22)} 50%,
                  transparent 60%,
                  transparent 100%
                );
              mask:
                linear-gradient(#000 0 0) content-box,
                linear-gradient(#000 0 0);
              mask-composite: exclude;
              pointer-events: none;
            }
          }
      }

      .sql-expression-single{
        margin: 0;
        border: 0 !important;
        border-top: 1px solid ${window.jimuConfig.isBuilder?t.sys.color.surface.background:t.sys.color.divider.secondary} !important;
        border-radius: 0 !important;
        background-color: transparent !important;
      }
    }

  `}const l=e=>{const t=e.theme;return s.css`
    .style-button{
    }
    .style-warning{
      color: ${t.sys.color.warning.main};
    }
    .style-popper{
      .style-popper-content{
        width: 180px;
        display: flex;
        flex-wrap: wrap;
        padding: 10px;
        max-height: 300px;
        height: auto;
        overflow: auto;

        .style-item{
          margin: 5px;
          padding: 0;
          background-color: ${t.ref.palette.white};

          &.active {
            outline: 2px solid ${t.sys.color.action.selected.default};
          }
        }
      }

    }
  `};function o(e){const t=e.theme;return s.css`
    .group-sql-expression-builder {

      margin: 0.875rem;
      margin-bottom: 0;
      .no-data-tip{
        text-align: center;
        margin: 2rem auto 0;
        opacity: 0.7;
      }
      .content-container {
        min-height: 425px;
        .fields-container {
          width: 623px;
          .fields-container-label {
            font-size: 16px;
            font-weight: 500;
            color: ${t.sys.color.surface.backgroundText};
          }
          .type-label {
            font-size: 14px;
            font-weight: 500;
            color: ${t.sys.color.surface.backgroundHint};
          }
          .main-field {
            padding-right: 0.75rem;
            margin-bottom: 1.5rem;
          }
          .field-list {
            padding-right: 0.75rem;
            max-height: calc(100vh - 380px);
            overflow-y: auto;
          }
          .field-item {
            background-color: ${t.sys.color.surface.paper};
            padding: 13px 12px;
            margin-bottom: 0.5rem;
            .data-field-container {
              .data-source-selector {
                width: 240px;
                position: relative;
                .data-source-selector-inner {
                  width: 100%;
                  position: absolute;
                  top: -6px;
                  margin-left: 0.25rem;
                  .main-ds-label {
                    color: ${t.sys.color.surface.paperText};
                  }
                  .view-ds-label {
                    margin-top: 0.125rem;
                    font-size: 12px;
                    color: ${t.sys.color.surface.paperHint};
                  }
                }
              }
              .field-selector {
                width: 206px;
              }
              .and-or-container {
                width: 75px;
              }
            }
            .case-sensitive-container {
              width: 120px;
              display: flex;
              justify-content: end;
              .case-sensitive-btn {
                overflow: visible;
              }
              .case-sensitive-btn, .more-input-setting-btn, .duplicate-btn, .delete-btn{
                .jimu-badge-badge {
                  border-color: ${t.ref.palette.black};
                }
              }
              .case-sensitive-btn.disabled, .case-sensitive-btn.disabled:hover, .case-sensitive-btn:disabled:hover{
                background-color: ${t.sys.color.action.disabled.default};
                border: none;
              }
              .case-sensitive-btn:disabled .jimu-icon {
                opacity: 0.5;
              }
              .jimu-badge-badge:not(.jimu-badge-badge-color-primary) {
                top: -2px;
              }
            }
          }
        }
        .clause-container {
          width: 239px;
          margin-top: 42px;
          margin-left: 0.75rem;
          padding-left: ${s.polished.rem(19)};
          border-left: 2px solid ${t.sys.color.divider.secondary};
          .clause-container-label {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: -0.5rem;
            color: ${t.sys.color.surface.backgroundHint};
          }
          .sql-expression-single.for-group-filter {
            padding-top: 10px;
            padding-left: 0;
            padding-right: 0;
            background-color: transparent;
            .clause-main-container {
              display: block;
              width: 100%;
              .clause-operator-container {
                width: 100%;
                margin: 0;
              }
              .clause-style-container {
                margin: 0;
                margin-top: 0.75rem;
                .input-editor {
                  width: calc(100% - 35px) !important;
                }
              }
            }
            .ask-for-value-container {
              margin-left: 0;
              margin-right: 0;
            }
          }
        }
      }
    }
  `}const r=e=>{const t=e.theme;return s.css`
    width:100%;
    .sort-title {
        margin-bottom: 20px;
        color: ${t.ref.palette.black};
        font-size: 16px;
    }
    .padding-0 {
        padding: 0;
    }
    .ml-0 {
        margin-left: 0;
    }
    .delete-all-button {
        cursor: pointer;
    }
    .jimu-tree-item__body {
        margin-bottom: 10px;
        background: ${t.sys.color.action.default};
        padding: 10px 10px 10px 0;
        box-shadow: 0 0 0 2px ${s.polished.rgba(t.ref.palette.white,.3)};
        flex: 1;
    }
    .multi-sort-select-con {
        & {
            display: flex;
            align-items: center;
            flex: 1;
        }
        .sort-field-selector {
            background:${t.ref.palette.white};
            border-radius: 2px;
            flex: 1;
            width: 0
        }

        .delete-button {
            cursor: pointer;
            text-align:right;
            margin-left: ${s.polished.rem(2)};
        }
        .delete-button svg {
            margin-right:0;
        }
    }
    .delete-sort-con {
        & {
            margin-left:5px;
        }
        .sort-button-l {
            border-radius: 2px 0 0 2px;
            border-right:none;
        }
        .sort-button-r {
            border-radius: 0px 2px 2px 0px;
            border-left:none;
        }
        .sort-button {
            border-color: ${t.sys.color.divider.primary};
        }
        svg {
            margin-right:0;
        }
    }
    .add-option .add-option-button{
        & {
            width:100%;
            font-size:14px;
            display: block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            margin-bottom: ${s.polished.rem(16)};
        }
        svg {
            margin-right:0;
            margin-right:5px;
        }
    }
    .no-sort-remind {
        margin: 2rem auto 0;
        opacity: 0.7;
        font-size: 13px;
        text-align: center;
    }
  `};var n=p(1888),d=p(67386),c=p(14321),u=p(13089),g=p(76117);class m extends s.React.PureComponent{constructor(){super(...arguments),this.i18nMessage=e=>this.props.intl.formatMessage({id:e,defaultMessage:c.defaultMessages[e]}),this.onChange=e=>{this.props&&this.props.onChange(e.target.value)}}render(){const e=this.props.list?this.props.list:this.props.value?[this.props.value]:[];return(0,d.jsx)(c.Select,{size:window.jimuConfig.isBuilder?"sm":"default","aria-label":this.i18nMessage("operatorSelector"),value:this.props.value||"",onChange:this.onChange,children:e.map((e,s)=>{const t=this.i18nMessage((0,g.getCamelCase)(e));return(0,d.jsx)("option",{value:e,label:t,children:t},s)})})}}const v=(0,s.injectIntl)(m);var x=p(58593),f=p.n(x),y=function(e,s){var t={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&s.indexOf(i)<0&&(t[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var a=0;for(i=Object.getOwnPropertySymbols(e);a<i.length;a++)s.indexOf(i[a])<0&&Object.prototype.propertyIsEnumerable.call(e,i[a])&&(t[i[a]]=e[i[a]])}return t};const M=e=>{const t=window.SVG,{className:i}=e,a=y(e,["className"]),l=(0,s.classNames)("jimu-icon jimu-icon-component",i);return t?(0,d.jsx)(t,Object.assign({className:l,src:f()},a)):(0,d.jsx)("svg",Object.assign({className:l},a))};class b extends s.React.PureComponent{constructor(e){super(e),this.i18nMessage=e=>this.props.intl.formatMessage({id:e,defaultMessage:c.defaultMessages[e]}),this.onTypeSelect=e=>{e!==this.props.sourceType&&this.props.onSelect(e)},this.toggle=()=>{this.setState({isOpen:!this.state.isOpen})},this.state={isOpen:!1}}render(){const{list:e,sourceType:t,hideFieldType:i=!1}=this.props;return(0,d.jsx)("div",{className:"source-type-selector",children:(0,d.jsxs)(c.Dropdown,{menuRole:"listbox",activeIcon:!0,"aria-label":this.i18nMessage("sourceType"),children:[(0,d.jsx)(c.DropdownButton,{icon:!0,arrow:!1,dot:!0,size:window.jimuConfig.isBuilder?"sm":"default",type:"primary","data-toggle":"dropdown",onClick:this.toggle,title:this.i18nMessage("sourceType"),children:(0,d.jsx)(M,{className:"text-default dropdown-icon"})}),(0,d.jsxs)(c.DropdownMenu,{showArrow:!0,strategy:"fixed",appendToBody:!window.jimuConfig.isBuilder,children:[(0,d.jsx)(c.DropdownItem,{header:!0,children:this.i18nMessage("sourceType")}),e&&Object.keys(e).map((e,a)=>i&&e===s.ClauseSourceType.Field?null:(0,d.jsx)(c.DropdownItem,{onClick:()=>{this.onTypeSelect(e)},active:t===e,children:this.i18nMessage((0,g.getCamelCase)(e))},a))]})]})})}}const S=(0,s.injectIntl)(b);var w=p(83710),j=p.n(w),C=function(e,s){var t={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&s.indexOf(i)<0&&(t[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var a=0;for(i=Object.getOwnPropertySymbols(e);a<i.length;a++)s.indexOf(i[a])<0&&Object.prototype.propertyIsEnumerable.call(e,i[a])&&(t[i[a]]=e[i[a]])}return t};const O=e=>{const t=window.SVG,{className:i}=e,a=C(e,["className"]),l=(0,s.classNames)("jimu-icon jimu-icon-component",i);return t?(0,d.jsx)(t,Object.assign({className:l,src:j()},a)):(0,d.jsx)("svg",Object.assign({className:l},a))};class z extends s.React.PureComponent{constructor(e){super(e),this.i18nMessage=e=>this.props.intl.formatMessage({id:e,defaultMessage:c.defaultMessages[e]}),this.onTypeSelect=(e,t)=>{if(e.stopPropagation(),e.nativeEvent.stopImmediatePropagation(),t!==this.state.inputEditorType){if([g.ClauseInputEditor.UniquePillWrapSelector,g.ClauseInputEditor.MultiplePillWrapSelector].includes(t))if(this.props.codedValues)this.changeValueOptionByInputType(t,this.props.codedValues.length);else{const e={where:"(1=1)",returnGeometry:!1,outFields:[this.props.fieldName],returnDistinctValues:!0};this.props.dataSource.queryCount(e,{scope:s.QueryScope.InConfigView,widgetId:"check_count"}).then(e=>{this.changeValueOptionByInputType(t,e.count)})}else this.changeValueOptionByInputType(t)}else this.setState({isWarningShown:!1})},this.changeValueOptionByInputType=(e,t)=>{if(t&&t>20)this.setState({isWarningShown:!0});else{this.setState({inputEditorType:e});s.lodash.debounce(()=>{this.props.onSelect(e),this.toggle()},200)()}},this.toggle=()=>{if(this.state.isOpen){s.lodash.debounce(()=>{(0,s.focusElementInKeyboardMode)(this.styleBtnRef)},200)()}this.setState({isWarningShown:!1,isOpen:!this.state.isOpen})},this.getWarningDOM=()=>this.state.isWarningShown&&(0,d.jsxs)("div",{className:"style-warning ml-2",role:"alert","aria-live":"polite",children:[(0,d.jsx)(O,{className:"mr-2"}),this.i18nMessage("invalidStyleWarning")]}),this.rtl=(0,s.getAppStore)().getState().appContext.isRTL?"_rtl":"",this.state={isOpen:!1,isWarningShown:!1,inputEditorType:this.props.inputEditorType}}componentDidUpdate(e,s){e.inputEditorType!==this.props.inputEditorType&&this.setState({inputEditorType:this.props.inputEditorType})}render(){return(0,d.jsxs)("div",{className:(0,s.classNames)(" style-type-selector align-items-center",this.props.className,{"d-flex":!this.props.isForGroupFilter}),children:[this.props.isForGroupFilter&&(0,d.jsx)("div",{className:"mb-1",children:this.getWarningDOM()}),(0,d.jsx)("div",{className:"style-button",children:(0,d.jsx)(c.Button,{ref:e=>{this.styleBtnRef=e},size:"sm",className:"pl-4 pr-4 text-nowrap",type:"primary",onClick:this.toggle,"aria-label":this.i18nMessage("chooseStyle"),children:this.i18nMessage("chooseStyle")})}),!this.props.isForGroupFilter&&this.getWarningDOM(),(0,d.jsx)(c.Popper,{strategy:"fixed",disablePortal:!0,reference:this.styleBtnRef,open:this.state.isOpen,toggle:this.toggle,arrowOptions:!0,className:this.props.className,flipOptions:!0,children:(0,d.jsx)("div",{className:"style-popper",children:(0,d.jsx)("div",{className:"style-popper-content",children:this.props.list.map((e,t)=>{const i=this.i18nMessage((0,g.getCamelCase)(e));return(0,d.jsx)(c.Tooltip,{title:i,placement:"bottom",children:(0,d.jsx)(c.Button,{icon:!0,type:"tertiary","aria-label":i,onClick:s=>{this.onTypeSelect(s,e)},className:(0,s.classNames)("style-item",{active:this.state.inputEditorType===e}),children:(0,d.jsx)(c.Icon,{className:"thumbnail",width:68,height:48,currentColor:!1,icon:p(18180)(`./style_${e.toLowerCase()}${this.rtl}.svg`)})})},t)})})})})]})}}const A=(0,n.withStyles)((0,s.injectIntl)(z),"InputEditorTypeSelector");var N=p(54112),T=p.n(N),k=function(e,s){var t={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&s.indexOf(i)<0&&(t[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var a=0;for(i=Object.getOwnPropertySymbols(e);a<i.length;a++)s.indexOf(i[a])<0&&Object.prototype.propertyIsEnumerable.call(e,i[a])&&(t[i[a]]=e[i[a]])}return t};const B=e=>{const t=window.SVG,{className:i}=e,a=k(e,["className"]),l=(0,s.classNames)("jimu-icon jimu-icon-component",i);return t?(0,d.jsx)(t,Object.assign({className:l,src:T()},a)):(0,d.jsx)("svg",Object.assign({className:l},a))};var F=p(23932),L=p.n(F),D=function(e,s){var t={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&s.indexOf(i)<0&&(t[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var a=0;for(i=Object.getOwnPropertySymbols(e);a<i.length;a++)s.indexOf(i[a])<0&&Object.prototype.propertyIsEnumerable.call(e,i[a])&&(t[i[a]]=e[i[a]])}return t};const V=e=>{const t=window.SVG,{className:i}=e,a=D(e,["className"]),l=(0,s.classNames)("jimu-icon jimu-icon-component",i);return t?(0,d.jsx)(t,Object.assign({className:l,src:L()},a)):(0,d.jsx)("svg",Object.assign({className:l},a))};var I=p(11595),H=p.n(I),E=function(e,s){var t={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&s.indexOf(i)<0&&(t[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var a=0;for(i=Object.getOwnPropertySymbols(e);a<i.length;a++)s.indexOf(i[a])<0&&Object.prototype.propertyIsEnumerable.call(e,i[a])&&(t[i[a]]=e[i[a]])}return t};const _=e=>{const t=window.SVG,{className:i}=e,a=E(e,["className"]),l=(0,s.classNames)("jimu-icon jimu-icon-component",i);return t?(0,d.jsx)(t,Object.assign({className:l,src:H()},a)):(0,d.jsx)("svg",Object.assign({className:l},a))};var q=p(85543),P=p.n(q),R=function(e,s){var t={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&s.indexOf(i)<0&&(t[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var a=0;for(i=Object.getOwnPropertySymbols(e);a<i.length;a++)s.indexOf(i[a])<0&&Object.prototype.propertyIsEnumerable.call(e,i[a])&&(t[i[a]]=e[i[a]])}return t};const U=e=>{const t=window.SVG,{className:i}=e,a=R(e,["className"]),l=(0,s.classNames)("jimu-icon jimu-icon-component",i);return t?(0,d.jsx)(t,Object.assign({className:l,src:P()},a)):(0,d.jsx)("svg",Object.assign({className:l},a))};var $=p(8491),G=p.n($),W=function(e,s){var t={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&s.indexOf(i)<0&&(t[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var a=0;for(i=Object.getOwnPropertySymbols(e);a<i.length;a++)s.indexOf(i[a])<0&&Object.prototype.propertyIsEnumerable.call(e,i[a])&&(t[i[a]]=e[i[a]])}return t};const Q=e=>{const t=window.SVG,{className:i,autoFlip:a=!0}=e,l=W(e,["className","autoFlip"]),o=(0,s.classNames)("jimu-icon jimu-icon-component",i);return t?(0,d.jsx)(t,Object.assign({className:o,src:G(),autoFlip:a},l)):(0,d.jsx)("svg",Object.assign({className:o},l))};var K=p(90131),J=p.n(K),X=function(e,s){var t={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&s.indexOf(i)<0&&(t[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var a=0;for(i=Object.getOwnPropertySymbols(e);a<i.length;a++)s.indexOf(i[a])<0&&Object.prototype.propertyIsEnumerable.call(e,i[a])&&(t[i[a]]=e[i[a]])}return t};const Y=e=>{const t=window.SVG,{className:i,autoFlip:a=!0}=e,l=X(e,["className","autoFlip"]),o=(0,s.classNames)("jimu-icon jimu-icon-component",i);return t?(0,d.jsx)(t,Object.assign({className:o,src:J(),autoFlip:a},l)):(0,d.jsx)("svg",Object.assign({className:o},l))};var Z=p(80075),ee=p.n(Z),se=function(e,s){var t={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&s.indexOf(i)<0&&(t[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var a=0;for(i=Object.getOwnPropertySymbols(e);a<i.length;a++)s.indexOf(i[a])<0&&Object.prototype.propertyIsEnumerable.call(e,i[a])&&(t[i[a]]=e[i[a]])}return t};const te=e=>{const t=window.SVG,{className:i,autoFlip:a=!0}=e,l=se(e,["className","autoFlip"]),o=(0,s.classNames)("jimu-icon jimu-icon-component",i);return t?(0,d.jsx)(t,Object.assign({className:o,src:ee(),autoFlip:a},l)):(0,d.jsx)("svg",Object.assign({className:o},l))};var ie=p(14089),ae=p.n(ie),le=function(e,s){var t={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&s.indexOf(i)<0&&(t[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var a=0;for(i=Object.getOwnPropertySymbols(e);a<i.length;a++)s.indexOf(i[a])<0&&Object.prototype.propertyIsEnumerable.call(e,i[a])&&(t[i[a]]=e[i[a]])}return t};const oe=e=>{const t=window.SVG,{className:i,autoFlip:a=!0}=e,l=le(e,["className","autoFlip"]),o=(0,s.classNames)("jimu-icon jimu-icon-component",i);return t?(0,d.jsx)(t,Object.assign({className:o,src:ae(),autoFlip:a},l)):(0,d.jsx)("svg",Object.assign({className:o},l))},re=[s.ClauseSourceType.SingleSelectFromUnique,s.ClauseSourceType.MultipleSelectFromUnique];class ne extends s.React.PureComponent{constructor(e){super(e),this.getFieldObj=()=>{const e=this.props.dataSource.getSchema().fields;this.fieldObj=this.props.clause.jimuFieldName?(0,s.Immutable)(e[this.props.clause.jimuFieldName]):null},this._updateTwoStates=(e,s,t)=>{this._updateCaseSensitiveState(e,s),this._updateAskForValueState(e,s),t&&this.setState({rerender:!this.state.rerender})},this.i18nMessage=e=>this.props.intl.formatMessage({id:e,defaultMessage:c.defaultMessages[e]}),this.isCascadeSupported=()=>!this.props.isForGroupFilter&&re.includes(this.props.clause.valueOptions.sourceType),this.isSortSupported=()=>re.includes(this.props.clause.valueOptions.sourceType)||this.props.clause.valueOptions.sourceType===s.ClauseSourceType.UserInput&&this.codedValues,this.isEmptyOptionHiddenSupported=()=>this.props.clause.valueOptions.sourceType===s.ClauseSourceType.SingleSelectFromUnique||this.props.clause.valueOptions.sourceType===s.ClauseSourceType.UserInput&&this.codedValues,this.getOperatorsByField=e=>{let s=[];return e&&e.type&&(s=(0,g.getOperatorsByShortType)(e.type,e.esriType)),s},this.deleteClause=()=>{this.props.onChange(null)},this.toggleCaseSensitive=()=>{this.onChanged({caseSensitive:!this.props.clause.caseSensitive})},this.duplicateClause=()=>{this.props.onChange(this.props.clause,!0)},this.toggleValueLabelPanel=()=>{this.setState({isValueLabelPanelShown:!this.state.isValueLabelPanelShown})},this.getLabel=(e=this.props.clause)=>{let s="";if(e.operator){const t=this.i18nMessage((0,g.getCamelCase)(e.operator));s=(0,g.getClauseLabel)(e,this.fieldObj,t,this.props.isForGroupFilter)}return s},this.onAskForValueOptsChange=e=>{const s=Object.assign({},this.props.clause.askForValueOptions,e);this.onChanged({askForValueOptions:s})},this.onLabelAccept=(e,t)=>{const i=this.i18nMessage((0,g.getCamelCase)(this.props.clause.operator)),a=(0,g.getClauseDefaultLabel)(this.props.clause,this.fieldObj,i,this.props.isForGroupFilter);if(e=e.trim(),t){if(""===e||e===a){this.setState({displayLabel:a});return void s.lodash.debounce(()=>{this.onChanged({displayLabel:null})},200)()}this.setState({displayLabel:e}),this.onChanged({displayLabel:e})}else{const s=e===a?null:e;this.onAskForValueOptsChange({label:s})}},this.onLabelChange=e=>{this.setState({displayLabel:e.target.value})},this.setValueLabelStatus=e=>{let t={displayType:e,askForValueOptions:null,displayLabel:null};if(e===s.ClauseDisplayType.UseAskForValue)t.askForValueOptions=this.getAskForValueOptions();else{const e=this.props.clause.valueOptions,s=this.displayTypeList[e.sourceType][0];if(e.inputEditor!==s){const e=Object.assign({},this.props.clause.valueOptions,{inputEditor:s});t=Object.assign({},t,{valueOptions:e})}}this.onChanged(t)},this.setDisplayLabelCheckbox=e=>{let t=s.ClauseDisplayType.None,i=null;e&&(t=s.ClauseDisplayType.UseLabel,i=this.getLabel(Object.assign({},this.props.clause,{displayType:s.ClauseDisplayType.UseLabel}))),this.setState({displayLabel:i}),this.setValueLabelStatus(t)},this.getAskForValueOptions=(e=!1)=>({label:null,display:s.ClauseLabelDisplay.Block,hint:"",cascade:e||this.isCascadeSupported()?s.ClauseCascade.None:null}),this.onFieldChange=e=>{const t=e[0];if(!t)return;this.fieldObj=(0,s.Immutable)(t);const i=this._updateOptionsByField(t);this._updateTwoStates(this.operatorList[0],i.sourceType),this.onChanged({jimuFieldName:t.jimuName,operator:this.operatorList[0],caseSensitive:!1,displayType:s.ClauseDisplayType.None,askForValueOptions:null,displayLabel:null,valueOptions:i})},this._updateOptionsByField=(e,s)=>(this.operatorList=this.getOperatorsByField(e),s=s||this.operatorList[0],this._updateOptionsByOperator(e,s,e.jimuName)),this.onOperatorChange=e=>{const t=this._updateOptionsByOperator(this.fieldObj,e,this.fieldObj.jimuName);this._updateTwoStates(e,t.sourceType);const i=this.shouldOpenAskForValueAutomatically(t.sourceType);this.onChanged({operator:e,caseSensitive:!1,displayType:i?s.ClauseDisplayType.UseAskForValue:s.ClauseDisplayType.None,askForValueOptions:i?this.getAskForValueOptions(i):null,displayLabel:null,valueOptions:t})},this._updateOptionsByOperator=(e,s,t)=>{const i=(0,g.getDisplayTypes)(this.props.mode,e,s,this.props.dataSource,t);return this.displayTypeList=i.displayTypes,this.displayTypeListAtRuntime=i.displayTypesAtRuntime,this.codedValues=i.codedValues,(0,g.getDefaultClauseValObj)(i.defaultSourceType,i.defaultInputEditorType)},this.onValueOptsChange=e=>{e.inputEditor!==this.props.clause.valueOptions.inputEditor&&(e.inputEditor=this.props.clause.valueOptions.inputEditor),this.onChanged({valueOptions:e})},this.isUniqueOrMultipleOnOutputDS=e=>{const t=this.props.dataSource.getDataSourceJson().isOutputFromWidget,i=[s.ClauseSourceType.SingleSelectFromUnique,s.ClauseSourceType.MultipleSelectFromUnique].includes(e);return t&&i},this.isOutputDsAndNoCodedValuesWhenUniqueOrMultiple=e=>this.isUniqueOrMultipleOnOutputDS(e)&&!this.codedValues,this.isPredefinedClause=e=>e===s.ClauseSourceType.SingleSelectFromPredefined||e===s.ClauseSourceType.MultipleSelectFromPredefined,this.shouldOpenAskForValueAutomatically=e=>this.isPredefinedClause(e)||this.isUniqueOrMultipleOnOutputDS(e),this._resetToDefaultDateInputEditor=e=>{var t;return this.props.mode===s.SqlExpressionMode.All&&this.fieldObj.type===s.JimuFieldType.Date&&e===s.ClauseSourceType.UserInput&&!!(null===(t=this.fieldObj.fieldFormat)||void 0===t?void 0:t.timeStyle)},this.onSourceTypeSelect=e=>{let t="";Object.keys(this.displayTypeList).some(s=>s===e&&(t=this.displayTypeList[s][0],this._resetToDefaultDateInputEditor(s)&&(t=this.displayTypeList[s][1]),!0)),this._updateAskForValueState(this.props.clause.operator,e);const i=(0,g.getDefaultClauseValObj)(e,t),a=this.shouldOpenAskForValueAutomatically(e);this.onChanged({valueOptions:i,displayType:a?s.ClauseDisplayType.UseAskForValue:s.ClauseDisplayType.None,askForValueOptions:a?this.getAskForValueOptions(a):null,displayLabel:null})},this.showInputEditorTypeSelector=e=>{let t=this.state.supportAskForValue&&e.displayType===s.ClauseDisplayType.UseAskForValue&&this.displayTypeList&&this.getInputTypeList(e).length>1&&!this.isOutputDsAndNoCodedValuesWhenUniqueOrMultiple(e.valueOptions.sourceType);return[s.JimuFieldType.DateOnly,s.JimuFieldType.TimeOnly].includes(e.operator)&&(t=t&&(e.valueOptions.inputEditor===g.ClauseInputEditor.SimpleSelect||e.valueOptions.inputEditor===g.ClauseInputEditor.UniquePillWrapSelector)),t},this.getInputTypeValue=e=>{const{sourceType:t,inputEditorAtRuntime:i}=e.valueOptions;return t===s.ClauseSourceType.SingleSelectFromPredefined?i||g.ClauseInputEditor.SimpleSelect:t===s.ClauseSourceType.MultipleSelectFromPredefined?i||g.ClauseInputEditor.MultipleSelect:e.valueOptions.inputEditor},this.getInputTypeList=e=>{const{sourceType:s}=e.valueOptions;return this.displayTypeListAtRuntime[s]||this.displayTypeList[s]},this.getInputTypeCodedValues=e=>{const{sourceType:s,value:t}=e.valueOptions;return this.isPredefinedClause(s)?t||[]:this.codedValues},this.onInputTypeSelect=e=>{const{sourceType:s,inputEditor:t}=this.props.clause.valueOptions;let i;i=this.isPredefinedClause(s)?{inputEditor:t,inputEditorAtRuntime:e}:{inputEditor:e},this.onChanged({valueOptions:Object.assign({},this.props.clause.valueOptions,i)})},this.getValueOptions=()=>{const e=this.props.clause.valueOptions;if(this.displayTypeList&&this.displayTypeList[e.sourceType]){const t=this.displayTypeList[e.sourceType][0];if((this.fieldObj.type===s.JimuFieldType.Date||this.fieldObj.type===s.JimuFieldType.DateOnly)&&e.sourceType===s.ClauseSourceType.UserInput)return e;if(e.inputEditor!==t)return Object.assign({},e,{inputEditor:t})}return e},this.getControllers=(e,t)=>{const i=!this.props.isHosted&&t&&e.caseSensitive;return(0,d.jsxs)("div",{className:"clause-controllers-container d-flex justify-content-end",children:[this.state.supportCaseSensitive&&(0,d.jsx)(c.Button,{className:"case-sensitive-btn",onClick:this.toggleCaseSensitive,icon:!0,size:"sm",variant:"text",color:"inherit",disabled:!(!this.props.isHosted&&t),title:this.i18nMessage("caseSensitive"),"aria-label":this.i18nMessage("caseSensitive"),"aria-pressed":i,children:(0,d.jsx)(c.Badge,{dot:!0,color:"primary",hideBadge:!i,children:(0,d.jsx)(U,{})})}),this.props.mode===s.SqlExpressionMode.All&&(0,d.jsx)(c.Button,{variant:"text",color:"inherit",onClick:this.toggleValueLabelPanel,icon:!0,size:"sm",className:(0,s.classNames)("more-input-setting-btn",{"more-input-setting-btn-active":this.state.isValueLabelPanelShown}),title:this.i18nMessage("moreInputSettings"),"aria-label":this.i18nMessage("moreInputSettings"),"aria-pressed":e.displayType!==s.ClauseDisplayType.None,"aria-expanded":this.state.isValueLabelPanelShown,children:(0,d.jsx)(c.Badge,{dot:!0,color:"primary",hideBadge:e.displayType===s.ClauseDisplayType.None,children:(0,d.jsx)(B,{})})}),(0,d.jsx)(c.Button,{variant:"text",color:"inherit",onClick:this.duplicateClause,icon:!0,size:"sm",className:"duplicate-btn",title:this.i18nMessage("duplicate"),"aria-label":this.i18nMessage("duplicate"),children:(0,d.jsx)(V,{})}),(0,d.jsx)(c.Button,{variant:"text",color:"inherit",onClick:this.deleteClause,icon:!0,size:"sm",className:"delete-btn",title:this.i18nMessage("deleteClause"),"aria-label":this.i18nMessage("deleteClause"),children:(0,d.jsx)(_,{})})]})},this.isPredefinedWithNoValues=e=>{var s;return this.isPredefinedClause(e.valueOptions.sourceType)&&(!e.valueOptions.value||0===(null===(s=e.valueOptions.value)||void 0===s?void 0:s.length))},this.onChanged=e=>{let s=Object.assign({},this.props.clause,e),t=!0;if(this.isPredefinedWithNoValues(s)?t=!1:null!==s.askForValueOptions||s.operator.includes("BLANK")||(t=!(null===s.valueOptions.value||s.valueOptions.value.filter(e=>null===e||null===(null==e?void 0:e.value)).length>0)),t!==s.valueOptions.isValid){const e=(0,g.getDefaultClauseValObj)(s.valueOptions.sourceType,s.valueOptions.inputEditor,s.valueOptions.value,t);s=Object.assign({},s,{valueOptions:e})}this.props.onChange(s)},this._isMounted=!1,this.getFieldObj(),this.codedValues=this.props.clause&&this.fieldObj?this.getCodedValues():null,this.state={rerender:!1,displayLabel:this.getLabel(),supportCaseSensitive:!1,supportAskForValue:!1,isValueLabelPanelShown:this.props.isForGroupFilter}}getCodedValues(){return(0,g.getInputEditorListByOperatorAndSourceType)(this.props.clause.operator,this.props.clause.valueOptions.sourceType,this.props.dataSource,this.fieldObj.jimuName).codedValues}componentDidMount(){this._isMounted=!1,this.props.clause.operator&&(this._updateOptionsByField(this.fieldObj,this.props.clause.operator),this._updateTwoStates(this.props.clause.operator,this.props.clause.valueOptions.sourceType,!0))}componentDidUpdate(e,s){var t,i;if(this._isMounted)return;const a=this.props.clause.jimuFieldName!==e.clause.jimuFieldName,l=this.props.clause.operator!==e.clause.operator;if(a&&(this.getFieldObj(),this.operatorList=this.getOperatorsByField(this.fieldObj)),a||l){const e=(0,g.getDisplayTypes)(this.props.mode,this.fieldObj,this.props.clause.operator,this.props.dataSource,this.fieldObj.jimuName);this.displayTypeList=e.displayTypes,this.displayTypeListAtRuntime=e.displayTypesAtRuntime,this.codedValues=e.codedValues,this._updateTwoStates(this.props.clause.operator,this.props.clause.valueOptions.sourceType,!0)}else(null===(t=this.props.clause.valueOptions)||void 0===t?void 0:t.value)!==(null===(i=e.clause.valueOptions)||void 0===i?void 0:i.value)&&null===this.props.clause.displayLabel&&this.setState({displayLabel:this.getLabel()})}componentWillMount(){this._isMounted=!0}_updateCaseSensitiveState(e,s){const t=(0,g.isCaseSensitiveSupportedByOperatorAndSourceType)(e,s);this.setState({supportCaseSensitive:t})}_updateAskForValueState(e,s){const t=(0,g.isAskForValueSupportedByOperatorAndSourceType)(e,s);this.setState({supportAskForValue:t})}render(){var e,t,i,a,l;const{clause:o,className:r="",sizeMode:n,dataSource:p,isForGroupFilter:h=!1}=this.props,{sortType:m="VALUE",sortOrder:x=s.SqlQuerySortOrder.Asc,isEmptyOptionHidden:f}=o.askForValueOptions||{},y=this.getLabel(),M=!o.operator||!o.operator.includes("BLANK"),b=this.shouldOpenAskForValueAutomatically(null===(e=o.valueOptions)||void 0===e?void 0:e.sourceType);return(0,d.jsx)("div",{className:r,children:(0,d.jsxs)("div",{className:(0,s.classNames)("sql-expression-single",{"for-group-filter":h}),children:[(0,d.jsxs)("div",{className:"sql-expression-clause",children:[n!==g.SqlExpressionSizeMode.Large&&!h&&this.getControllers(o,M),(0,d.jsxs)("div",{className:"w-100 clause-main-container",children:[(0,d.jsxs)("div",{className:"clause-field-and-operator",children:[!h&&(0,d.jsx)("div",{className:"clause-field-container",children:(0,d.jsx)(u.FieldSelector,{dataSources:[p],useDefault:!0,onChange:this.onFieldChange,selectedFields:this.fieldObj?(0,s.Immutable)([this.fieldObj.jimuName]):null,hiddenFields:p.type===s.DataSourceTypes.SubtypeSublayer?(0,s.Immutable)([p.getLayerDefinition().subtypeField]):null,isDataSourceDropDownHidden:!0,useDropdown:!0,dropdownProps:{size:window.jimuConfig.isBuilder?"sm":"default"}})}),(0,d.jsx)("div",{className:"clause-operator-container",children:(0,d.jsx)(v,{onChange:this.onOperatorChange,value:o.operator,list:this.operatorList})})]}),(0,d.jsxs)("div",{className:"clause-style-container",children:[M&&(0,d.jsx)(S,{onSelect:this.onSourceTypeSelect,list:this.displayTypeList,sourceType:o.valueOptions.sourceType,hideFieldType:h}),M&&(0,d.jsx)(g.InputEditorRender,{"aria-label":this.i18nMessage("values"),sortType:m,sortOrder:x,onChange:this.onValueOptsChange,dataSource:p,codedValues:this.codedValues,valueOptions:this.getValueOptions(),fieldObj:this.fieldObj,runtime:!window.jimuConfig.isBuilder,isFromBuilder:!0,isSmallSize:n===g.SqlExpressionSizeMode.Small,isEmptyOptionHidden:f})]}),n===g.SqlExpressionSizeMode.Large&&this.getControllers(o,M)]})]}),this.state.isValueLabelPanelShown&&(0,d.jsxs)("div",{className:"ask-for-value-container",children:[(0,d.jsx)("div",{className:"ask-for-value-radio d-flex mr-5",children:(0,d.jsxs)(c.Label,{check:!0,centric:!0,children:[(0,d.jsx)(c.Radio,{style:{cursor:"pointer"},className:"mr-2 align-text-bottom",onChange:e=>{this.setValueLabelStatus(s.ClauseDisplayType.None)},checked:o.displayType!==s.ClauseDisplayType.UseAskForValue,disabled:b}),this.i18nMessage("unAskForValues")]})}),o.displayType!==s.ClauseDisplayType.UseAskForValue&&(0,d.jsxs)("div",{className:"ask-for-value-options align-items-center mt-2",children:[(0,d.jsxs)(c.Label,{check:!0,centric:!0,children:[(0,d.jsx)(c.Checkbox,{style:{cursor:"pointer"},className:"mr-2",checked:o.displayType===s.ClauseDisplayType.UseLabel,onChange:e=>{this.setDisplayLabelCheckbox(e.target.checked)}}),this.i18nMessage("displayLabel")]}),o.displayType===s.ClauseDisplayType.UseLabel&&(0,d.jsx)("div",{className:"use-label-input",children:(0,d.jsx)(c.TextInput,{size:"sm",type:"text","aria-label":this.i18nMessage("displayLabel"),value:this.state.displayLabel,onChange:this.onLabelChange,onAcceptValue:e=>{this.onLabelAccept(e,!0)}})})]}),(0,d.jsxs)("div",{className:"ask-for-value-radio-selector d-flex align-items-center",children:[this.state.supportAskForValue&&(0,d.jsx)("div",{className:"ask-for-value-radio d-flex",children:(0,d.jsxs)(c.Label,{check:!0,centric:!0,children:[(0,d.jsx)(c.Radio,{style:{cursor:"pointer"},className:"mr-2 align-text-bottom",onChange:()=>{this.setValueLabelStatus(s.ClauseDisplayType.UseAskForValue)},checked:o.displayType===s.ClauseDisplayType.UseAskForValue,disabled:b}),this.i18nMessage("askForValues")]})}),this.showInputEditorTypeSelector(o)&&(0,d.jsx)("div",{className:"ask-for-value-item ask-for-value-middle-item pl-6",children:(0,d.jsx)(A,{fieldName:null===(t=this.fieldObj)||void 0===t?void 0:t.name,dataSource:p,isForGroupFilter:!0,codedValues:this.getInputTypeCodedValues(o),inputEditorType:this.getInputTypeValue(o),list:this.getInputTypeList(o),onSelect:this.onInputTypeSelect})})]}),this.state.supportAskForValue&&o.displayType===s.ClauseDisplayType.UseAskForValue&&(0,d.jsxs)("div",{className:"ask-for-value-options-container",children:[(0,d.jsxs)("div",{className:"ask-for-value-options",children:[(0,d.jsxs)(c.Label,{className:(0,s.classNames)("ask-for-value-item p-1",{"col-md-3":!h}),children:[(0,d.jsx)("div",{className:"ask-for-value-item-label",children:this.i18nMessage("label")}),(0,d.jsxs)("div",{className:"d-flex",children:[(0,d.jsx)(c.TextInput,{size:"sm",type:"text",style:{width:"calc(100% - 55px)"},defaultValue:y,onChange:e=>{this.onLabelAccept(e.target.value)}}),(0,d.jsxs)(c.AdvancedButtonGroup,{className:"label-display-buttons pl-1",children:[(0,d.jsx)(c.Button,{onClick:()=>{this.onAskForValueOptsChange({display:s.ClauseLabelDisplay.Block})},icon:!0,size:"sm",disabled:""===y,title:this.i18nMessage("inlineLabel"),"aria-label":this.i18nMessage("inlineLabel"),active:(null===(i=o.askForValueOptions)||void 0===i?void 0:i.display)===s.ClauseLabelDisplay.Block,children:(0,d.jsx)(Y,{autoFlip:!0})}),(0,d.jsx)(c.Button,{onClick:()=>{this.onAskForValueOptsChange({display:s.ClauseLabelDisplay.Inline})},icon:!0,size:"sm",disabled:""===y,title:this.i18nMessage("separateLabel"),"aria-label":this.i18nMessage("separateLabel"),active:!(null===(a=o.askForValueOptions)||void 0===a?void 0:a.display)||(null===(l=o.askForValueOptions)||void 0===l?void 0:l.display)===s.ClauseLabelDisplay.Inline,children:(0,d.jsx)(Q,{autoFlip:!0})})]})]})]}),(0,d.jsxs)(c.Label,{className:(0,s.classNames)("ask-for-value-item ask-for-value-middle-item p-1",{"col-md-3":!h}),children:[(0,d.jsx)("div",{className:"ask-for-value-item-label",children:this.i18nMessage("hint")}),(0,d.jsx)(c.TextInput,{type:"text",defaultValue:o.askForValueOptions?o.askForValueOptions.hint:"",size:"sm",onBlur:e=>{this.onAskForValueOptsChange({hint:e.target.value})}})]}),this.isCascadeSupported()&&(0,d.jsxs)(c.Label,{className:(0,s.classNames)("ask-for-value-item p-1",{"col-md-3":!h}),children:[(0,d.jsx)("div",{className:"ask-for-value-item-label text-truncate",title:this.i18nMessage("cascade"),children:this.i18nMessage("cascade")}),(0,d.jsxs)(c.Select,{size:"sm",value:o.askForValueOptions?o.askForValueOptions.cascade:s.ClauseCascade.None,onChange:e=>{this.onAskForValueOptsChange({cascade:e.target.value})},children:[(0,d.jsx)("option",{value:s.ClauseCascade.None,children:this.i18nMessage("noneCascadeTip")},0),(0,d.jsx)("option",{value:s.ClauseCascade.Previous,children:this.i18nMessage("previousCascadeTip")},1),(0,d.jsx)("option",{value:s.ClauseCascade.All,children:this.i18nMessage("allCascadeTip")},2)]})]}),this.isSortSupported()&&(0,d.jsxs)("div",{className:(0,s.classNames)("ask-for-value-item p-1",{"col-md-3":!h}),children:[(0,d.jsx)("div",{className:"ask-for-value-item-label text-truncate",title:this.i18nMessage("sortBy"),children:this.i18nMessage("sortBy")}),(0,d.jsxs)("div",{className:"d-flex",children:[(0,d.jsxs)(c.Select,{size:"sm",value:m,"aria-label":this.i18nMessage("sortBy"),onChange:e=>{this.onAskForValueOptsChange({sortType:e.target.value})},children:[(0,d.jsx)("option",{value:"VALUE",children:this.i18nMessage("value")},0),this.codedValues&&(0,d.jsx)("option",{value:"LABEL",children:this.i18nMessage("label")},1)]}),(0,d.jsx)(c.Button,{icon:!0,size:"sm",className:"pl-1",title:this.i18nMessage(x===s.SqlQuerySortOrder.Asc?"ascending":"descending"),"aria-label":this.i18nMessage(x===s.SqlQuerySortOrder.Asc?"ascending":"descending"),onClick:()=>{this.onAskForValueOptsChange({sortOrder:x===s.SqlQuerySortOrder.Asc?s.SqlQuerySortOrder.Desc:s.SqlQuerySortOrder.Asc})},children:x===s.SqlQuerySortOrder.Asc?(0,d.jsx)(te,{autoFlip:!0}):(0,d.jsx)(oe,{autoFlip:!0})})]})]})]}),this.isEmptyOptionHiddenSupported()&&(0,d.jsx)("div",{className:(0,s.classNames)("ask-for-value-options pl-1",{"mt-2":h}),children:(0,d.jsxs)(c.Label,{check:!0,centric:!0,children:[(0,d.jsx)(c.Checkbox,{style:{cursor:"pointer"},className:"mr-2",checked:!f,onChange:e=>{this.onAskForValueOptsChange({isEmptyOptionHidden:!e.target.checked})}}),this.i18nMessage("showAllOption")]})})]})]})]})})}}const pe=(0,n.withStyles)((0,s.injectIntl)(ne),"SqlExpressionClause");var he=p(5629),de=p.n(he),ce=function(e,s){var t={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&s.indexOf(i)<0&&(t[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var a=0;for(i=Object.getOwnPropertySymbols(e);a<i.length;a++)s.indexOf(i[a])<0&&Object.prototype.propertyIsEnumerable.call(e,i[a])&&(t[i[a]]=e[i[a]])}return t};const ue=e=>{const t=window.SVG,{className:i}=e,a=ce(e,["className"]),l=(0,s.classNames)("jimu-icon jimu-icon-component",i);return t?(0,d.jsx)(t,Object.assign({className:l,src:de()},a)):(0,d.jsx)("svg",Object.assign({className:l},a))};class ge extends s.React.PureComponent{constructor(e){super(e),this.i18nMessage=e=>this.props.intl.formatMessage({id:e,defaultMessage:c.defaultMessages[e]}),this.addClause=e=>{e.__id=(0,s.uuidv1)(),this.onChange({parts:this.props.clauseSet.parts.concat(e)})},this.duplicateClauseSet=()=>{this.props.onChange(this.props.clauseSet,!0)},this.deleteClauseSet=()=>{this.props.onChange(null)},this.changeAndOR=e=>{this.onChange({logicalOperator:e})},this.onClauseChange=(e,t,i)=>{if(i)return void this.addClause(e.asMutable({deep:!0}));const a=this.props.clauseSet.parts,l={};null===e&&2===a.length&&(l.logicalOperator=s.ClauseLogic.And),2===a.length&&2===a.filter(e=>""===e.jimuFieldName).length?(l.parts=(0,g.getClauseArrayByChange)(a,e,"clause_set_clause_0"),e.__id=e.__id+"-2",l.parts=(0,g.getClauseArrayByChange)(l.parts,e,"clause_set_clause_1")):l.parts=(0,g.getClauseArrayByChange)(a,e,t),0!==l.parts.length?this.onChange(l):this.props.onChange(null)},this.onChange=e=>{const s=Object.assign({},this.props.clauseSet,e);this.props.onChange(s)},this.LogicalOperator=null}render(){const{logicalOperator:e,parts:t}=this.props.clauseSet,i=t||(0,s.Immutable)([]);return(0,d.jsx)("div",{className:this.props.className?this.props.className:"",children:0===i.length?null:(0,d.jsxs)("div",{className:"sql-expression-set",children:[(0,d.jsxs)("div",{className:"btn-container "+(i.length<2?"justify-content-end":"justify-content-between"),children:[i.length<2?null:(0,d.jsxs)(c.AdvancedButtonGroup,{className:"and-or-container",children:[(0,d.jsx)(c.Button,{active:e===s.ClauseLogic.And,onClick:()=>{this.changeAndOR(s.ClauseLogic.And)},size:"sm",children:this.i18nMessage("and")}),(0,d.jsx)(c.Button,{active:e===s.ClauseLogic.Or,onClick:()=>{this.changeAndOR(s.ClauseLogic.Or)},className:"ml-0",size:"sm",children:this.i18nMessage("or")})]}),(0,d.jsx)("div",{className:"set-badge",children:this.i18nMessage("clauseSet")}),(0,d.jsxs)("div",{className:"add-button-container",children:[(0,d.jsx)(c.Button,{variant:"text",color:"inherit",onClick:e=>{this.addClause((0,g.getDefaultSingleClause)())},className:"mr-1",icon:!0,size:"sm",title:this.i18nMessage("addClause"),"aria-label":this.i18nMessage("addClause"),children:(0,d.jsx)(ue,{})}),(0,d.jsx)(c.Button,{variant:"text",color:"inherit",onClick:e=>{this.duplicateClauseSet()},className:"mr-1",icon:!0,size:"sm",title:this.i18nMessage("duplicate"),"aria-label":this.i18nMessage("duplicate"),children:(0,d.jsx)(V,{})}),(0,d.jsx)(c.Button,{variant:"text",color:"inherit",onClick:this.deleteClauseSet,icon:!0,size:"sm",title:this.i18nMessage("deleteClauseSet"),"aria-label":this.i18nMessage("deleteClauseSet"),children:(0,d.jsx)(_,{})})]})]}),i.map((e,s)=>(0,d.jsx)(pe,{clause:e,isHosted:this.props.isHosted,mode:this.props.mode,sizeMode:this.props.sizeMode,dataSource:this.props.dataSource,onChange:(e,t)=>{this.onClauseChange(e,"clause_set_clause_"+s,t)}},e.__id))]})})}}const me=(0,n.withStyles)((0,s.injectIntl)(ge),"SqlExpressionClauseSet");class ve extends s.React.PureComponent{constructor(e){var t;super(e),this.sqlExpressionListConRef=s.React.createRef(),this.sqlExpressionBuilderRef=s.React.createRef(),this.getDataSource=()=>{const e=this.props.dataSource;return e.dataViewId===s.CONSTANTS.SELECTION_DATA_VIEW_ID?e.getMainDataSource():e},this.i18nMessage=e=>this.props.intl.formatMessage({id:e,defaultMessage:c.defaultMessages[e]}),this.getRenderedBackgroundColor=e=>{let s=e;for(;s;){const e=window.getComputedStyle(s).backgroundColor;if(e&&"transparent"!==e&&"rgba(0, 0, 0, 0)"!==e)return e;s=s.parentElement}return window.getComputedStyle(document.body).backgroundColor||"transparent"},this.applyClauseSetBadgeBackground=()=>{if(window.jimuConfig.isBuilder)return;const e=this.sqlExpressionBuilderRef.current;if(!e)return;const s=this.getRenderedBackgroundColor(e);e.style.setProperty("--clause-set-badge-bg",s)},this.addClauseByType=(e,t)=>{t||(t=e?(0,g.getDefaultSingleClause)():(0,g.getDefaultClauseSet)(),t=this.getPartsArray((0,s.Immutable)([t]),"add")[0]);const i=this.state.partsArray.concat(t);this.setState({partsArray:i});const a=i.length<2?{parts:i,logicalOperator:s.ClauseLogic.And}:{parts:i};this.onChange(a)},this.changeAndOR=e=>{this.onChange({logicalOperator:e})},this.onClauseChange=(e,t,i)=>{if(i){const t=this.getPartsArray((0,s.Immutable)([e]),"update")[0];return void this.addClauseByType(e.type===s.ClauseType.Single,t)}const a=(0,g.getClauseArrayByChange)(this.state.partsArray.asMutable({deep:!0}),e,t);this.setState({partsArray:(0,s.Immutable)(a)}),this.onChange({parts:a})},this.onChange=e=>{let t=this.props.expression||(0,s.Immutable)({logicalOperator:s.ClauseLogic.And,parts:[]});if(e.parts){const i=this.getPartsArray((0,s.Immutable)(e.parts),"remove");t=t.set("parts",i)}e.logicalOperator&&(t=t.set("logicalOperator",e.logicalOperator));const i=s.dataSourceUtils.getArcGISSQL(t,this.getDataSource());i.sql===t.sql&&i.displaySQL===t.displaySQL||(t=t.set("sql",i.sql).set("displaySQL",i.displaySQL)),this.props.onChange&&this.props.onChange(t)},this.getPartsArray=(e,t)=>{const i=e.map(e=>{var i;if((e=this._getNewClauseOrClauseSet(e,t).clause).type===s.ClauseType.Set){let s=!1;const a=null===(i=e.parts)||void 0===i?void 0:i.map(e=>{const i=this._getNewClauseOrClauseSet(e,t);return s=i.isUpdated||s,i.clause});s&&(e=e.set("parts",a))}return e});return i},this._getNewClauseOrClauseSet=(e,t)=>{let i=!0;return"remove"===t?e=s.Immutable.without(e,"__id"):"update"===t?e=s.Immutable.set(e,"__id",(0,s.uuidv1)()):e.__id?i=!1:e=s.Immutable.set(e,"__id",(0,s.uuidv1)()),{clause:e,isUpdated:i}},this.onResize=({width:e,height:s})=>{let t=g.SqlExpressionSizeMode.Medium;e<600?t=g.SqlExpressionSizeMode.Small:e>900&&(t=g.SqlExpressionSizeMode.Large),this.setState({sizeMode:t})},this.toggle=()=>{this.setState({isOpen:!this.state.isOpen})};const i=this.getDataSource();i&&(this.isHosted=s.dataSourceUtils.isAGOLHostedService(i.url)),this.state={sizeMode:g.SqlExpressionSizeMode.Large,isOpen:!1,partsArray:this.getPartsArray((null===(t=this.props.expression)||void 0===t?void 0:t.parts)||(0,s.Immutable)([]),"add")}}componentDidMount(){this.applyClauseSetBadgeBackground()}componentDidUpdate(e){const{forceUpdateExpression:t=!1,expression:i}=this.props;t&&e.expression!==i&&this.setState({partsArray:this.getPartsArray((null==i?void 0:i.parts)||(0,s.Immutable)([]),"add")})}render(){var e;const{sizeMode:t,partsArray:i}=this.state,a=(null===(e=this.props.expression)||void 0===e?void 0:e.logicalOperator)||s.ClauseLogic.And,l=this.props.mode?this.props.mode:s.SqlExpressionMode.All,o=this.getDataSource();return(0,d.jsx)("div",{className:(0,s.classNames)(this.props.className,"use-scroll",{"small-mode":t===g.SqlExpressionSizeMode.Small,"medium-mode":t===g.SqlExpressionSizeMode.Medium,"large-mode":t===g.SqlExpressionSizeMode.Large}),children:(0,d.jsx)(c.QueryScopeContext.Provider,{value:{scope:this.props.queryScope||s.QueryScope.InConfigView,widgetId:this.props.widgetId},children:(0,d.jsx)("div",{style:this.props.style,className:"sql-expression-builder",ref:this.sqlExpressionBuilderRef,children:o&&o.getSchema().fields?(0,d.jsxs)("div",{className:"sql-expression-container",children:[(0,d.jsxs)("div",{className:"builder-btn-container",style:{justifyContent:i.length<2?"flex-end":"space-between"},children:[i.length<2?null:(0,d.jsxs)(c.AdvancedButtonGroup,{className:"and-or-container",children:[(0,d.jsx)(c.Button,{active:a===s.ClauseLogic.And,onClick:()=>{this.changeAndOR(s.ClauseLogic.And)},size:t===g.SqlExpressionSizeMode.Small&&window.jimuConfig.isBuilder?"sm":"default",className:(0,s.classNames)("ml-0",{"jimu-outline-inside":t===g.SqlExpressionSizeMode.Small}),children:this.i18nMessage("and")}),(0,d.jsx)(c.Button,{onClick:()=>{this.changeAndOR(s.ClauseLogic.Or)},active:a===s.ClauseLogic.Or,size:t===g.SqlExpressionSizeMode.Small&&window.jimuConfig.isBuilder?"sm":"default",className:(0,s.classNames)("ml-0",{"jimu-outline-inside":t===g.SqlExpressionSizeMode.Small}),children:this.i18nMessage("or")})]}),t===g.SqlExpressionSizeMode.Small?(0,d.jsxs)(c.Dropdown,{activeIcon:!0,children:[(0,d.jsxs)(c.DropdownButton,{arrow:!1,type:"default","data-toggle":"dropdown",size:window.jimuConfig.isBuilder?"sm":"default","a11y-description":0===i.length?this.i18nMessage("noClauseTip"):"",className:"jimu-outline-inside",onClick:this.toggle,children:[(0,d.jsx)(ue,{className:"dropdown-icon"}),this.i18nMessage("add")]}),(0,d.jsxs)(c.DropdownMenu,{alignment:"end",appendToBody:!1,children:[(0,d.jsx)(c.DropdownItem,{"aria-label":this.i18nMessage("clause"),onClick:()=>{this.addClauseByType(!0)},children:this.i18nMessage("clause")}),(0,d.jsx)(c.DropdownItem,{"aria-label":this.i18nMessage("clauseSet"),onClick:()=>{this.addClauseByType()},children:this.i18nMessage("clauseSet")})]})]}):(0,d.jsxs)("div",{className:"add-button-container",children:[(0,d.jsxs)(c.Button,{className:"pl-6 pr-6","aria-label":this.i18nMessage("addClause"),"aria-describedby":"no-clause-tip",onClick:()=>{this.addClauseByType(!0)},children:[(0,d.jsx)(ue,{className:"mr-1"}),this.i18nMessage("addClause")]}),(0,d.jsxs)(c.Button,{className:"ml-2 pl-6 pr-6","aria-label":this.i18nMessage("addClauseSet"),onClick:()=>{this.addClauseByType()},children:[(0,d.jsx)(ue,{className:"mr-1"}),this.i18nMessage("addClauseSet")]})]})]}),(0,d.jsxs)("div",{className:"sql-expression-list",ref:this.sqlExpressionListConRef,children:[(0,d.jsx)(s.ReactResizeDetector,{targetRef:this.sqlExpressionListConRef,handleWidth:!0,handleHeight:!0,onResize:this.onResize}),0===i.length?(0,d.jsx)("div",{className:"no-data-tip",id:"no-clause-tip",children:this.props.noClauseMessage||this.i18nMessage("noClauseTip")}):i.map((e,i)=>e.type===s.ClauseType.Single?(0,d.jsx)(pe,{clause:e,isHosted:this.isHosted,mode:l,sizeMode:t,dataSource:o,onChange:(e,s)=>{this.onClauseChange(e,"clause_"+i,s)}},e.__id):(0,d.jsx)(me,{clauseSet:e,isHosted:this.isHosted,mode:l,sizeMode:t,dataSource:o,onChange:(e,s)=>{this.onClauseChange(e,"clause_set_"+i,s)}},e.__id))]})]}):(0,d.jsx)("div",{className:"no-data-tip",children:this.i18nMessage("noDataTip")})})})})}}const xe=(0,n.withStyles)((0,s.injectIntl)(ve),"SqlExpressionBuilder"),fe=xe;var ye=function(e,s){var t={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&s.indexOf(i)<0&&(t[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var a=0;for(i=Object.getOwnPropertySymbols(e);a<i.length;a++)s.indexOf(i[a])<0&&Object.prototype.propertyIsEnumerable.call(e,i[a])&&(t[i[a]]=e[i[a]])}return t};class Me extends s.React.PureComponent{constructor(e){super(e),this.externalDsStyle={maxWidth:"960px"},this.handleToggle=e=>{var t;if(void 0===e)return void(0,s.focusElementInKeyboardMode)(null===(t=this.headerRef.parentElement)||void 0===t?void 0:t.nextSibling);this.setState({isOpen:!1});const{toggle:i,isOpen:a}=this.props;void 0!==a&&i&&i(e)},this.handleOkBtn=()=>{(0,g.isSqlExpressionValid)(this.state.expression)?this.handleToggle(!0):this.setState({isValid:!1})},this.handleCancelBtn=()=>{this.setState({isValid:!0,expression:this.props.expression}),this.handleToggle(!1)},this.onModalClose=()=>{this.props.expression!==this.state.expression&&this.props.onChange&&this.props.onChange(this.state.expression)},this.i18nMessage=e=>{const{intl:s}=this.props;return s?s.formatMessage({id:e,defaultMessage:c.defaultMessages[e]}):""},this.onChange=e=>{this.setState({isValid:!0,expression:e})},this.state={isValid:!0,isOpen:!!e.isOpen,expression:this.props.expression}}componentDidUpdate(e,s){this.props.expression!==e.expression&&this.setState({expression:this.props.expression})}render(){let{isOpen:e}=this.props;e=void 0===e?this.state.isOpen:e;const t=this.props.intl.formatMessage({id:"ok",defaultMessage:s.defaultMessages.ok}),i=this.props.intl.formatMessage({id:"cancel",defaultMessage:s.defaultMessages.cancel}),a=this.props,{expression:l}=a,o=ye(a,["expression"]);return(0,d.jsxs)(c.Modal,{onClosed:this.onModalClose,backdrop:"static",centered:!0,isOpen:e,toggle:()=>{this.handleToggle(void 0)},className:"sql-expression-builder-modal",contentClassName:"border-0 h-100",style:this.externalDsStyle,returnfocusafterclose:"true",size:"lg",children:[(0,d.jsx)(c.ModalHeader,{tag:"h4",toggle:this.handleCancelBtn,children:(0,d.jsx)("span",{ref:e=>{this.headerRef=e},children:this.i18nMessage("sqlExpressionBuilder")})}),(0,d.jsx)(c.ModalBody,{children:(0,d.jsx)(fe,Object.assign({},o,{expression:this.state.expression,noScrollForList:!0,onChange:this.onChange}))}),(0,d.jsx)(c.ModalFooter,{children:(0,d.jsxs)("div",{className:"m-0 w-100 d-block",children:[!this.state.isValid&&(0,d.jsxs)("div",{role:"alert","aria-live":"polite",style:{color:this.props.theme.sys.color.error.main,fontSize:this.props.theme.sys.spacing(4),marginTop:"-32px",marginBottom:"8px"},children:[(0,d.jsx)(O,{color:this.props.theme.sys.color.error.main,className:"mr-2"}),this.i18nMessage("sqlExprIncomplete")]}),(0,d.jsxs)("div",{className:"d-flex",children:[(0,d.jsx)(c.Button,{"aria-label":t,type:"primary",onClick:this.handleOkBtn,className:"ml-auto mr-2",style:{minWidth:"64px"},children:t}),(0,d.jsx)(c.Button,{"aria-label":i,type:"secondary",onClick:this.handleCancelBtn,style:{minWidth:"64px"},children:i})]})]})})]})}}const be=(0,n.withTheme)((0,s.injectIntl)(Me));var Se=p(60158),we=p.n(Se),je=function(e,s){var t={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&s.indexOf(i)<0&&(t[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var a=0;for(i=Object.getOwnPropertySymbols(e);a<i.length;a++)s.indexOf(i[a])<0&&Object.prototype.propertyIsEnumerable.call(e,i[a])&&(t[i[a]]=e[i[a]])}return t};const Ce=e=>{const t=window.SVG,{className:i}=e,a=je(e,["className"]),l=(0,s.classNames)("jimu-icon jimu-icon-component",i);return t?(0,d.jsx)(t,Object.assign({className:l,src:we()},a)):(0,d.jsx)("svg",Object.assign({className:l},a))};class Oe extends s.React.PureComponent{constructor(e){super(e),this.i18nMessage=e=>this.props.intl.formatMessage({id:e,defaultMessage:c.defaultMessages[e]}),this.toggleCaseSensitive=()=>{const{clause:e}=this.props,s=Object.assign({},e,{caseSensitive:!e.caseSensitive});this.onChanged({clause:s})},this.onFieldChange=e=>{const{dataSources:t,logicalOperator:i}=this.props,a=this.showClauseLogic(e)?i:s.ClauseLogic.And,l={fieldList:e.map(e=>e.jimuName),logicalOperator:a};t&&(l.mainField=e[0]),this.onChanged(l)},this.changeAndOR=e=>{this.onChanged({logicalOperator:e})},this.onDataSourceChanged=e=>{this.onChanged({dataSourceId:e.target.value})},this.onChanged=e=>{const{dataSource:s,selectedFieldList:t,logicalOperator:i}=this.props,a=Object.assign({},{dataSourceId:s.id,fieldList:t,logicalOperator:i},e);this.props.onChange(a)},this.showClauseLogic=e=>(null==e?void 0:e.length)>(this.props.dataSources?2:1),this.getDsLabels=e=>{const s={main:e.getLabel(),view:this.i18nMessage("default")};return e.isDataView&&(s.main=e.getMainDataSource().getLabel(),s.view="selection"===e.dataViewId?this.i18nMessage("selectionDataView"):e.getLabel()),s},this._isMounted=!1,this.isHosted=s.dataSourceUtils.isAGOLHostedService(this.props.dataSource.url),this.state={supportCaseSensitive:this.supportCaseSensitive()}}componentDidMount(){this._isMounted=!1}componentDidUpdate(e,s){if(e.mainField!==this.props.mainField){const e=this.supportCaseSensitive();this.setState({supportCaseSensitive:e})}}componentWillMount(){this._isMounted=!0}supportCaseSensitive(){const{clause:e}=this.props;return(0,g.isCaseSensitiveSupportedByOperatorAndSourceType)(e.operator,e.valueOptions.sourceType)}render(){const{className:e="",clause:t,isMainDsHosted:i,logicalOperator:a,dataSources:l,dataSource:o,fieldTypes:r,disabledFields:n,selectedFieldList:p}=this.props,h=!t.operator||!t.operator.includes("BLANK"),g=i||!h,m=!i&&h&&t.caseSensitive,v=!i&&t.caseSensitive&&this.isHosted,x=this.getDsLabels(o);return(0,d.jsxs)("div",{className:(0,s.classNames)("field-item w-100 d-flex justify-content-between",e),children:[(0,d.jsxs)("div",{className:"data-field-container d-flex",children:[(0,d.jsx)("div",{className:"data-source-selector p-0",children:l?(0,d.jsx)(c.Select,{size:"sm",value:o.id,onChange:this.onDataSourceChanged,title:`${x.main} | ${x.view}`,children:l.map(e=>{const s=this.getDsLabels(e);return(0,d.jsx)(c.Option,{value:e.id,active:e.id===o.id,title:`${s.main} | ${s.view}`,children:(0,d.jsx)("div",{className:"text-truncate",children:`${s.main} | ${s.view}`})},e.id)})}):(0,d.jsxs)("div",{className:"data-source-selector-inner",title:x.main+" | "+x.view,children:[(0,d.jsx)("div",{className:"main-ds-label text-truncate",children:x.main}),(0,d.jsx)("div",{className:"view-ds-label",children:x.view})]})}),(0,d.jsx)("div",{className:"field-selector ml-4 d-flex",children:(0,d.jsx)(u.FieldSelector,{dataSources:[o],types:r,onChange:this.onFieldChange,isMultiple:!l,disabledFields:n,selectedFields:(0,s.Immutable)(p),isDataSourceDropDownHidden:!0,useMultiDropdownBottomTools:!0,useDropdown:!0,dropdownProps:{size:window.jimuConfig.isBuilder?"sm":"default"}})}),(0,d.jsx)("div",{className:"and-or-container ml-4",children:this.showClauseLogic(this.props.selectedFieldList)&&(0,d.jsxs)(c.AdvancedButtonGroup,{size:"sm",children:[(0,d.jsx)(c.Button,{active:a===s.ClauseLogic.And,onClick:()=>{this.changeAndOR(s.ClauseLogic.And)},size:"sm",children:this.i18nMessage("and")}),(0,d.jsx)(c.Button,{active:a===s.ClauseLogic.Or,onClick:()=>{this.changeAndOR(s.ClauseLogic.Or)},className:"ml-0",size:"sm",children:this.i18nMessage("or")})]})})]}),(0,d.jsx)("div",{className:"case-sensitive-container",children:this.state.supportCaseSensitive&&(0,d.jsx)(s.React.Fragment,{children:l?(0,d.jsx)(c.Button,{className:"case-sensitive-btn",type:"tertiary",icon:!0,size:"sm",title:this.i18nMessage("caseSensitive"),"aria-label":this.i18nMessage("caseSensitive"),"aria-pressed":m,disabled:g,onClick:this.toggleCaseSensitive,children:(0,d.jsx)(c.Badge,{dot:!0,color:"primary",hideBadge:!m,children:(0,d.jsx)(U,{})})}):(0,d.jsx)(s.React.Fragment,{children:v&&(0,d.jsx)(c.Tooltip,{title:this.i18nMessage("hostedDoesNotSupportCaseSensitiveQuery"),placement:"bottom",children:(0,d.jsx)("div",{children:(0,d.jsx)(c.Button,{className:"case-sensitive-btn",type:"tertiary",icon:!0,size:"sm","aria-pressed":m,disabled:!0,children:(0,d.jsx)(c.Badge,{badgeClassName:"border-0",badgeContent:(0,d.jsx)(Ce,{color:"var(--sys-color-warning-main)",size:"s"}),children:(0,d.jsx)(U,{})})})})})})})})]})}}const ze=(0,s.injectIntl)(Oe);class Ae extends s.React.PureComponent{constructor(e){super(e),this.i18nMessage=e=>this.props.intl.formatMessage({id:e,defaultMessage:c.defaultMessages[e]}),this.getDataSources=()=>{let e=[...this.props.dataSources];return this.props.expression&&(e=this.props.expression.asMutable({deep:!0}).map(e=>this.props.dataSources.find(s=>s.id===e.dataSourceId))),e},this.getGroupExpression=e=>{const{expression:s}=this.props;return s||(0,g.getDefaultGroupExpression)(e)},this.getMainFieldObject=e=>{const t=this.dataSources[0].getSchema().fields,i=Object.keys(t).filter(s=>s===e.jimuFieldName)[0];return(0,s.Immutable)(t[i])},this.onMainFieldItemChange=e=>{let t;if(e.dataSourceId!==this.state.expression[0].dataSourceId){const s=[...this.dataSources],i=s.findIndex(s=>s.id===e.dataSourceId);s.unshift(s.splice(i,1)[0]),t=(0,g.getDefaultGroupExpression)(s),this.dataSources=s,this.mainField=this.getMainFieldObject(t[0].clause)}else e.mainField?(this.mainField=e.mainField,t=(0,g.getDefaultGroupExpression)(this.dataSources,this.mainField)):(t=(0,s.Immutable)([...this.state.expression]),t=t.setIn(["0","clause","caseSensitive"],e.clause.caseSensitive));this.setState({expression:t})},this.onFieldItemChange=(e,t)=>{0===t&&(e.clause=this.state.expression[0].clause);const i=[...this.state.expression];i.splice(t,1,e),this.setState({expression:(0,s.Immutable)(i)})},this.onClauseChange=e=>{const t=Object.assign({},this.state.expression[0].asMutable({deep:!0}),{clause:e}),i=[...this.state.expression];i.splice(0,1,t),this.setState({expression:(0,s.Immutable)(i)})},this.dataSources=this.getDataSources();const t=this.getGroupExpression(this.dataSources);this.mainField=this.getMainFieldObject(t[0].clause),this.state={expression:t}}componentDidUpdate(e,s){s.expression!==this.state.expression&&this.props.onChange(this.state.expression)}render(){var e;const{className:t,style:i}=this.props,{expression:a}=this.state,l=s.dataSourceUtils.isAGOLHostedService(this.dataSources[0].url);return(0,d.jsx)("div",{className:t,children:(0,d.jsx)(c.QueryScopeContext.Provider,{value:{scope:s.QueryScope.InConfigView},children:(0,d.jsx)("div",{style:i,className:"group-sql-expression-builder",children:0===(null===(e=this.dataSources)||void 0===e?void 0:e.length)?(0,d.jsx)("div",{className:"no-data-tip",children:this.i18nMessage("noDataTip")}):(0,d.jsxs)("div",{className:"content-container d-flex",children:[(0,d.jsxs)("div",{className:"fields-container",children:[(0,d.jsx)(c.Label,{className:"fields-container-label mb-5",children:this.i18nMessage("addFields")}),(0,d.jsxs)("div",{className:"main-field w-100",children:[(0,d.jsx)(c.Label,{className:"type-label",children:this.i18nMessage("mainField")}),(0,d.jsx)(ze,{dataSources:this.dataSources,dataSource:this.dataSources[0],isMainDsHosted:l,selectedFieldList:(0,s.Immutable)([a[0].clause.jimuFieldName]),logicalOperator:a[0].logicalOperator,clause:a[0].clause,mainField:this.mainField,onChange:this.onMainFieldItemChange})]}),(0,d.jsx)(c.Label,{className:"type-label",children:this.i18nMessage("fieldList")}),(0,d.jsx)("div",{className:"field-list w-100 overflow-auto",children:null==a?void 0:a.map((e,t)=>(0,d.jsx)(ze,{dataSource:this.dataSources[t],isMainDsHosted:l,selectedFieldList:e.fieldList,logicalOperator:e.logicalOperator,clause:a[0].clause,mainField:this.mainField,fieldTypes:(0,s.Immutable)([this.mainField.type]),disabledFields:0===t?(0,s.Immutable)([this.mainField.jimuName]):null,onChange:e=>{this.onFieldItemChange(e,t)}},t))})]}),(0,d.jsxs)("div",{className:"clause-container flex-grow-1 pl-6",children:[(0,d.jsx)(c.Label,{className:"clause-container-label",children:this.i18nMessage("operatorAndValues")}),(0,d.jsx)(pe,{clause:a[0].clause,isHosted:l,mode:s.SqlExpressionMode.All,sizeMode:g.SqlExpressionSizeMode.Small,dataSource:this.dataSources[0],isForGroupFilter:!0,onChange:this.onClauseChange})]})]})})})})}}const Ne=(0,n.withStyles)((0,s.injectIntl)(Ae),"GroupSqlExpressionBuilder");var Te=function(e,s){var t={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&s.indexOf(i)<0&&(t[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var a=0;for(i=Object.getOwnPropertySymbols(e);a<i.length;a++)s.indexOf(i[a])<0&&Object.prototype.propertyIsEnumerable.call(e,i[a])&&(t[i[a]]=e[i[a]])}return t};class ke extends s.React.PureComponent{constructor(e){super(e),this.externalModalStyle={maxWidth:"960px",minHeight:"548px"},this.handleToggle=e=>{var t;if(void 0===e)return void(0,s.focusElementInKeyboardMode)(null===(t=this.headerRef.parentElement)||void 0===t?void 0:t.nextSibling);this.setState({isOpen:!1});const{toggle:i,isOpen:a}=this.props;void 0!==a&&i&&i(e)},this.handleOkBtn=()=>{var e;(null===(e=this.state.expression)||void 0===e?void 0:e[0].clause.valueOptions.isValid)?this.handleToggle(!0):this.setState({isValid:!1})},this.handleCancelBtn=()=>{this.setState({isValid:!0,expression:this.props.expression}),this.handleToggle(!1)},this.onModalClose=()=>{this.props.expression!==this.state.expression&&this.props.onChange&&this.props.onChange(this.state.expression)},this.i18nMessage=e=>{const{intl:s}=this.props;return s?s.formatMessage({id:e,defaultMessage:c.defaultMessages[e]}):""},this.onChange=e=>{this.setState({isValid:!0,expression:e})},this.state={isValid:!0,isOpen:!!e.isOpen,expression:this.props.expression}}componentDidUpdate(e,s){this.props.expression!==e.expression&&this.setState({expression:this.props.expression})}render(){let{isOpen:e}=this.props;e=void 0===e?this.state.isOpen:e;const t=this.props.intl.formatMessage({id:"ok",defaultMessage:s.defaultMessages.ok}),i=this.props.intl.formatMessage({id:"cancel",defaultMessage:s.defaultMessages.cancel}),a=this.props,{expression:l}=a,o=Te(a,["expression"]);return(0,d.jsxs)(c.Modal,{size:"lg",contentClassName:"border-0 h-100",style:this.externalModalStyle,backdrop:"static",centered:!0,returnfocusafterclose:"true",onClosed:this.onModalClose,isOpen:e,toggle:()=>{this.handleToggle(void 0)},children:[(0,d.jsx)(c.ModalHeader,{tag:"h4",toggle:this.handleCancelBtn,children:(0,d.jsx)("span",{ref:e=>{this.headerRef=e},children:this.i18nMessage("sqlExpressionBuilderForGroup")})}),(0,d.jsx)(c.ModalBody,{children:(0,d.jsx)(Ne,Object.assign({},o,{expression:this.state.expression,onChange:this.onChange}))}),(0,d.jsx)(c.ModalFooter,{className:"pt-0",children:(0,d.jsxs)("div",{className:"m-0 w-100 d-block",css:s.css`padding: 14px;`,children:[!this.state.isValid&&(0,d.jsxs)("div",{role:"alert","aria-live":"polite",style:{color:this.props.theme.sys.color.error.main,fontSize:this.props.theme.sys.spacing(4),marginTop:"-32px",marginBottom:"8px"},children:[(0,d.jsx)(O,{color:this.props.theme.sys.color.error.main,className:"mr-2"}),this.i18nMessage("sqlExprIncomplete")]}),(0,d.jsxs)("div",{className:"d-flex",children:[(0,d.jsx)(c.Button,{"aria-label":t,type:"primary",onClick:this.handleOkBtn,className:"ml-auto mr-2",style:{minWidth:"76px"},children:t}),(0,d.jsx)(c.Button,{"aria-label":i,type:"secondary",onClick:this.handleCancelBtn,style:{minWidth:"76px"},children:i})]})]})})]})}}const Be=(0,n.withTheme)((0,s.injectIntl)(ke));var Fe=p(98640);class Le extends s.React.PureComponent{constructor(e){super(e),this.onOptionChange=(e,s,t)=>{const i=this.deepClone(this.props.value);i[e][s]=t,this.props.onSortButtonClick?this.props.onSortButtonClick(i,e):this.props.onChange(i,e)},this.onSelectChange=(e,s)=>{const t=e[0];if(!t)return;const i=this.deepClone(this.props.value),a=t.name;i[s].jimuFieldName=a,this.props.onSelect?this.props.onSelect(i,s):this.props.onChange(i,s)},this.addOption=()=>{const e=Array.isArray(this.props.value),s=this.deepClone(this.state.option),t=e?this.deepClone(this.props.value):[];t.push(s),this.props.onAddOption?this.props.onAddOption(t):this.props.onChange(t)},this.delecteOption=e=>{const s=this.deepClone(this.props.value);s.splice(e,1),this.props.onDelete?this.props.onDelete(s):this.props.onChange(s)},this.deepClone=e=>{const s=Array.isArray(e)?[]:{};for(const t in e){const i=("object"==typeof e[t]||"function"==typeof e[t])&&null!==e[t];s[t]=i?this.deepClone(e[t]):e[t]}return s},this.createOptionElement=(e,t,i)=>{const a=this.props.value[i].jimuFieldName?(0,s.Immutable)([this.props.value[i].jimuFieldName]):(0,s.Immutable)([]),l=e=>{"Enter"===e.key&&this.onOptionChange(i,"order",t.order===s.OrderRule.Asc?s.OrderRule.Desc:s.OrderRule.Asc)},o=e=>{"Enter"===e.key&&this.delecteOption(i)};return(0,d.jsxs)("div",{className:"multi-sort-select-con",children:[this.props.useDataSource&&(0,d.jsx)("div",{className:"sort-field-selector",children:(0,d.jsx)(u.FieldSelector,{useDataSources:e,onChange:(e,s)=>{this.onSelectChange(e,i)},selectedFields:a,isDataSourceDropDownHidden:!0,useDropdown:!0,dropdownProps:{useKeyUpEvent:!0}})}),(0,d.jsx)("div",{className:"delete-sort-con",children:(0,d.jsxs)(c.Button,{size:"sm",icon:!0,type:"tertiary",className:"delete-button padding-0",title:t.order===s.OrderRule.Asc?this.nls("ascending"):this.nls("descending"),onKeyUp:e=>{l(e)},onClick:()=>{this.onOptionChange(i,"order",t.order===s.OrderRule.Asc?s.OrderRule.Desc:s.OrderRule.Asc)},children:[t.order===s.OrderRule.Asc&&(0,d.jsx)(te,{size:"s",className:"sort-arrow-down-icon ml-0"}),t.order===s.OrderRule.Desc&&(0,d.jsx)(oe,{size:"s",className:"sort-arrow-down-icon ml-0"})]})}),(0,d.jsx)(c.Button,{size:"sm",icon:!0,type:"tertiary",className:"delete-button padding-0",title:this.nls("deleteOption"),onKeyUp:e=>{o(e)},onClick:()=>{this.delecteOption(i)},children:(0,d.jsx)(_,{size:"s",className:"sort-arrow-down-icon ml-0"})})]})},this.nls=e=>this.props.intl?this.props.intl.formatMessage({id:e,defaultMessage:c.defaultMessages[e]}):e,this.onDataSourceCreated=e=>null,this.state={option:{jimuFieldName:"",order:s.OrderRule.Asc}}}render(){const{value:e}=this.props,t=this.props.intl.formatMessage({id:"invalidExpression",defaultMessage:c.defaultMessages.invalidExpression});return(0,d.jsxs)("div",{className:(0,s.classNames)("multi-sort",{[this.props.className]:!!this.props.className}),children:[(0,d.jsx)("div",{className:"add-option",children:(0,d.jsxs)(c.Button,{className:"add-option-button jimu-outline-inside",onClick:this.addOption,title:this.props.intl.formatMessage({id:"addSortField",defaultMessage:c.defaultMessages.addSortField}),children:[(0,d.jsx)(ue,{size:"s",className:"sort-arrow-down-icon"}),this.props.intl.formatMessage({id:"addSortField",defaultMessage:c.defaultMessages.addSortField})]})}),(0,d.jsx)(s.DataSourceComponent,{useDataSource:this.props.useDataSource,onDataSourceCreated:this.onDataSourceCreated,children:i=>Array.isArray(this.props.value)?(0,d.jsx)(Fe.List,{size:"sm",className:"setting-ui-unit-list",itemsJson:e.asMutable({deep:!0}).map((e,s)=>({itemStateDetailContent:e,itemKey:`${s}`})),dndEnabled:!0,onDidDrop:(e,s)=>{const{itemJsons:[,t]}=s.props;this.props.onChange(t.map(e=>e.itemStateDetailContent))},overrideItemBlockInfo:({itemBlockInfo:e})=>({name:Fe.TreeItemActionType.RenderOverrideItem,children:[{name:Fe.TreeItemActionType.RenderOverrideItemDroppableContainer,children:[{name:Fe.TreeItemActionType.RenderOverrideItemDraggableContainer,children:[{name:Fe.TreeItemActionType.RenderOverrideItemBody,children:[{name:Fe.TreeItemActionType.RenderOverrideItemDragHandle},{name:Fe.TreeItemActionType.RenderOverrideItemMainLine}]}]}]}]}),renderOverrideItemMainLine:(e,t)=>{var i;const{itemJsons:a}=t.props,l=a[0],o=a[1];return this.createOptionElement((0,s.Immutable)([null===(i=this.props.useDataSource)||void 0===i?void 0:i.asMutable({deep:!0})]),l.itemStateDetailContent,o.indexOf(l))}}):t}),Array.isArray(e)&&0===e.length&&(0,d.jsxs)("div",{className:"no-sort-remind",children:[(0,d.jsx)("div",{children:this.props.intl.formatMessage({id:"noSortRemindText",defaultMessage:c.defaultMessages.noSortRemindText})}),(0,d.jsx)("div",{children:this.props.intl.formatMessage({id:"pleaseAddOne",defaultMessage:c.defaultMessages.pleaseAddOne})})]})]})}}const De=(0,n.withStyles)((0,s.injectIntl)(Le),"Sort");(0,n.registerStyles)("jimu-ui/advanced/sql-expression-builder/",e)})(),h})())}}});